-- GENERATED 2026-10-01 - do not hand-edit
RecommendedStatsData_Meta = {
    ["schema"] = 1,
    ["updated"] = "2026-10-01",
    ["gamePatch"] = "12.1.0",
    ["sampleSize"] = 20,
    ["source"] = "raider.io + Battle.net API",
}
