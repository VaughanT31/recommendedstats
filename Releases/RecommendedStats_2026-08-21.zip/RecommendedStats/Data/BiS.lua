-- GENERATED 2026-08-21 - do not hand-edit
RecommendedStatsData_BiS = {
    ["SHAMAN_ENHANCEMENT_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271483,
            ["pct"] = 40,
        },
        ["NECK"] = {
            ["itemID"] = 268291,
            ["pct"] = 40,
        },
        ["SHOULDER"] = {
            ["itemID"] = 249977,
            ["pct"] = 40,
        },
        ["CHEST"] = {
            ["itemID"] = 249982,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 251155,
            ["pct"] = 30,
        },
        ["LEGS"] = {
            ["itemID"] = 271482,
            ["pct"] = 40,
        },
        ["FEET"] = {
            ["itemID"] = 268287,
            ["pct"] = 60,
        },
        ["WRIST"] = {
            ["itemID"] = 159380,
            ["pct"] = 30,
        },
        ["HANDS"] = {
            ["itemID"] = 271484,
            ["pct"] = 40,
        },
        ["BACK"] = {
            ["itemID"] = 159288,
            ["pct"] = 20,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237850,
            ["pct"] = 80,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 193767,
            ["pct"] = 30,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 70,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251217,
            ["pct"] = 20,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 40,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 193701,
            ["pct"] = 30,
        },
    },
    ["SHAMAN_ENHANCEMENT_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 247035,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 246190,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 247041,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 247546,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 247537,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 240302,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 247578,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 240300,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 247564,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 247489,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 242567,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 242589,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 245997,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 246199,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 245999,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 246000,
            ["pct"] = 100,
        },
    },
    ["MONK_MISTWEAVER_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250015,
            ["pct"] = 44,
        },
        ["NECK"] = {
            ["itemID"] = 151309,
            ["pct"] = 22,
        },
        ["SHOULDER"] = {
            ["itemID"] = 251223,
            ["pct"] = 33,
        },
        ["CHEST"] = {
            ["itemID"] = 250018,
            ["pct"] = 44,
        },
        ["WAIST"] = {
            ["itemID"] = 159301,
            ["pct"] = 33,
        },
        ["LEGS"] = {
            ["itemID"] = 250014,
            ["pct"] = 44,
        },
        ["FEET"] = {
            ["itemID"] = 251153,
            ["pct"] = 22,
        },
        ["WRIST"] = {
            ["itemID"] = 244576,
            ["pct"] = 22,
        },
        ["HANDS"] = {
            ["itemID"] = 250016,
            ["pct"] = 44,
        },
        ["BACK"] = {
            ["itemID"] = 250010,
            ["pct"] = 33,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245770,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 56,
        },
        ["FINGER_2"] = {
            ["itemID"] = 159459,
            ["pct"] = 22,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 44,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249808,
            ["pct"] = 44,
        },
    },
    ["MONK_MISTWEAVER_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 250015,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 50228,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250013,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 250018,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 49806,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 250014,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 250017,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 244576,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 250016,
            ["pct"] = 75,
        },
        ["BACK"] = {
            ["itemID"] = 250010,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237843,
            ["pct"] = 25,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 193709,
            ["pct"] = 25,
        },
        ["TABARD"] = {
            ["itemID"] = 69210,
            ["pct"] = 25,
        },
        ["SHIRT"] = {
            ["itemID"] = 268274,
            ["pct"] = 25,
        },
        ["FINGER_1"] = {
            ["itemID"] = 49812,
            ["pct"] = 75,
        },
        ["FINGER_2"] = {
            ["itemID"] = 268290,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249808,
            ["pct"] = 75,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249343,
            ["pct"] = 50,
        },
    },
    ["PALADIN_PROTECTION_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 251126,
            ["pct"] = 25,
        },
        ["NECK"] = {
            ["itemID"] = 273781,
            ["pct"] = 63,
        },
        ["SHOULDER"] = {
            ["itemID"] = 239037,
            ["pct"] = 25,
        },
        ["CHEST"] = {
            ["itemID"] = 249964,
            ["pct"] = 38,
        },
        ["WAIST"] = {
            ["itemID"] = 159418,
            ["pct"] = 38,
        },
        ["LEGS"] = {
            ["itemID"] = 249960,
            ["pct"] = 63,
        },
        ["FEET"] = {
            ["itemID"] = 193728,
            ["pct"] = 38,
        },
        ["WRIST"] = {
            ["itemID"] = 237834,
            ["pct"] = 25,
        },
        ["HANDS"] = {
            ["itemID"] = 249962,
            ["pct"] = 38,
        },
        ["BACK"] = {
            ["itemID"] = 251132,
            ["pct"] = 38,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237839,
            ["pct"] = 63,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 237831,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 251136,
            ["pct"] = 25,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251217,
            ["pct"] = 25,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249342,
            ["pct"] = 38,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249343,
            ["pct"] = 38,
        },
    },
    ["PALADIN_PROTECTION_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 211993,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 215136,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 211991,
            ["pct"] = 100,
        },
        ["SHIRT"] = {
            ["itemID"] = 41248,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 211996,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 225589,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 211992,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 222429,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 222435,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 211994,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 225574,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222440,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 222432,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 215135,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 212450,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 219314,
            ["pct"] = 100,
        },
    },
    ["HUNTER_SURVIVAL_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 249988,
            ["pct"] = 75,
        },
        ["NECK"] = {
            ["itemID"] = 268291,
            ["pct"] = 75,
        },
        ["SHOULDER"] = {
            ["itemID"] = 50233,
            ["pct"] = 25,
        },
        ["CHEST"] = {
            ["itemID"] = 249991,
            ["pct"] = 75,
        },
        ["WAIST"] = {
            ["itemID"] = 244581,
            ["pct"] = 25,
        },
        ["LEGS"] = {
            ["itemID"] = 249987,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 159388,
            ["pct"] = 75,
        },
        ["WRIST"] = {
            ["itemID"] = 244584,
            ["pct"] = 75,
        },
        ["HANDS"] = {
            ["itemID"] = 249989,
            ["pct"] = 75,
        },
        ["BACK"] = {
            ["itemID"] = 251132,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237847,
            ["pct"] = 50,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 237837,
            ["pct"] = 25,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 75,
        },
        ["FINGER_2"] = {
            ["itemID"] = 249920,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 250228,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 193701,
            ["pct"] = 25,
        },
    },
    ["HUNTER_SURVIVAL_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 212020,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 178707,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 212018,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 212023,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 221075,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 212019,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 219335,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 219342,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 212021,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 133363,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222448,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 221141,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 215135,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 133282,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 212454,
            ["pct"] = 50,
        },
    },
    ["PRIEST_DISCIPLINE_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250051,
            ["pct"] = 20,
        },
        ["NECK"] = {
            ["itemID"] = 268291,
            ["pct"] = 60,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271553,
            ["pct"] = 40,
        },
        ["CHEST"] = {
            ["itemID"] = 271558,
            ["pct"] = 40,
        },
        ["WAIST"] = {
            ["itemID"] = 239649,
            ["pct"] = 40,
        },
        ["LEGS"] = {
            ["itemID"] = 250050,
            ["pct"] = 40,
        },
        ["FEET"] = {
            ["itemID"] = 268282,
            ["pct"] = 60,
        },
        ["WRIST"] = {
            ["itemID"] = 159263,
            ["pct"] = 20,
        },
        ["HANDS"] = {
            ["itemID"] = 250052,
            ["pct"] = 40,
        },
        ["BACK"] = {
            ["itemID"] = 272225,
            ["pct"] = 40,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245770,
            ["pct"] = 20,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 193766,
            ["pct"] = 20,
        },
        ["SHIRT"] = {
            ["itemID"] = 89195,
            ["pct"] = 20,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 80,
        },
        ["FINGER_2"] = {
            ["itemID"] = 273792,
            ["pct"] = 40,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 40,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250215,
            ["pct"] = 20,
        },
    },
    ["PRIEST_DISCIPLINE_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 237709,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 185820,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 237707,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 229337,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 221121,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 237708,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 237524,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 185814,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 242490,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 185821,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 222566,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 221141,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 231265,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 219314,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 232545,
            ["pct"] = 100,
        },
    },
    ["MONK_BREWMASTER_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250015,
            ["pct"] = 78,
        },
        ["NECK"] = {
            ["itemID"] = 268291,
            ["pct"] = 33,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250013,
            ["pct"] = 67,
        },
        ["SHIRT"] = {
            ["itemID"] = 167196,
            ["pct"] = 11,
        },
        ["CHEST"] = {
            ["itemID"] = 250018,
            ["pct"] = 44,
        },
        ["WAIST"] = {
            ["itemID"] = 159301,
            ["pct"] = 22,
        },
        ["LEGS"] = {
            ["itemID"] = 251130,
            ["pct"] = 33,
        },
        ["FEET"] = {
            ["itemID"] = 151317,
            ["pct"] = 22,
        },
        ["WRIST"] = {
            ["itemID"] = 244576,
            ["pct"] = 33,
        },
        ["HANDS"] = {
            ["itemID"] = 250016,
            ["pct"] = 67,
        },
        ["BACK"] = {
            ["itemID"] = 159288,
            ["pct"] = 22,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237847,
            ["pct"] = 22,
        },
        ["TABARD"] = {
            ["itemID"] = 5976,
            ["pct"] = 11,
        },
        ["FINGER_1"] = {
            ["itemID"] = 251513,
            ["pct"] = 56,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251148,
            ["pct"] = 33,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 44,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250215,
            ["pct"] = 22,
        },
    },
    ["MONK_BREWMASTER_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 240775,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 246194,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 240345,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 247533,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 240778,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 240779,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 240780,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 240781,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 247154,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 240260,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 242596,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 245997,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 246198,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 246000,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 246203,
            ["pct"] = 100,
        },
    },
    ["WARRIOR_FURY_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271456,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 251142,
            ["pct"] = 25,
        },
        ["SHOULDER"] = {
            ["itemID"] = 249950,
            ["pct"] = 75,
        },
        ["CHEST"] = {
            ["itemID"] = 249955,
            ["pct"] = 75,
        },
        ["WAIST"] = {
            ["itemID"] = 268289,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 271455,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 193728,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 237834,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 249953,
            ["pct"] = 25,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237846,
            ["pct"] = 50,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 193755,
            ["pct"] = 25,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 158366,
            ["pct"] = 25,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249342,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249343,
            ["pct"] = 50,
        },
    },
    ["WARRIOR_FURY_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 211984,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 224594,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 211982,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 211987,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 211981,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 211983,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 212443,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 212437,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 211985,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 222817,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 212407,
            ["pct"] = 50,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 212388,
            ["pct"] = 50,
        },
        ["TABARD"] = {
            ["itemID"] = 23192,
            ["pct"] = 50,
        },
        ["SHIRT"] = {
            ["itemID"] = 52019,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 212447,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 223006,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 212454,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 219672,
            ["pct"] = 50,
        },
    },
    ["DEATHKNIGHT_UNHOLY_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 249970,
            ["pct"] = 67,
        },
        ["NECK"] = {
            ["itemID"] = 273781,
            ["pct"] = 67,
        },
        ["SHOULDER"] = {
            ["itemID"] = 249968,
            ["pct"] = 33,
        },
        ["CHEST"] = {
            ["itemID"] = 249973,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 159442,
            ["pct"] = 33,
        },
        ["LEGS"] = {
            ["itemID"] = 249969,
            ["pct"] = 67,
        },
        ["FEET"] = {
            ["itemID"] = 237828,
            ["pct"] = 33,
        },
        ["WRIST"] = {
            ["itemID"] = 237834,
            ["pct"] = 67,
        },
        ["HANDS"] = {
            ["itemID"] = 249971,
            ["pct"] = 67,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 67,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237842,
            ["pct"] = 33,
        },
        ["FINGER_1"] = {
            ["itemID"] = 158366,
            ["pct"] = 67,
        },
        ["FINGER_2"] = {
            ["itemID"] = 162544,
            ["pct"] = 33,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249344,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249343,
            ["pct"] = 67,
        },
    },
    ["DEATHKNIGHT_UNHOLY_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 247555,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 246190,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 247556,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 247508,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 247552,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 247554,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 247558,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 247510,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 247549,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 247512,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 242563,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 245997,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 246199,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 245999,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 246000,
            ["pct"] = 100,
        },
    },
    ["ROGUE_ASSASSINATION_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250006,
            ["pct"] = 40,
        },
        ["NECK"] = {
            ["itemID"] = 251234,
            ["pct"] = 40,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271508,
            ["pct"] = 40,
        },
        ["CHEST"] = {
            ["itemID"] = 271513,
            ["pct"] = 60,
        },
        ["WAIST"] = {
            ["itemID"] = 268286,
            ["pct"] = 40,
        },
        ["LEGS"] = {
            ["itemID"] = 271509,
            ["pct"] = 60,
        },
        ["FEET"] = {
            ["itemID"] = 244569,
            ["pct"] = 20,
        },
        ["WRIST"] = {
            ["itemID"] = 244576,
            ["pct"] = 40,
        },
        ["HANDS"] = {
            ["itemID"] = 250007,
            ["pct"] = 40,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 40,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237837,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 275070,
            ["pct"] = 40,
        },
        ["FINGER_1"] = {
            ["itemID"] = 159459,
            ["pct"] = 40,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251136,
            ["pct"] = 40,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 60,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 270168,
            ["pct"] = 40,
        },
    },
    ["ROGUE_ASSASSINATION_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 237664,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 215136,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 237662,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 237667,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 237533,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 237663,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 243306,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 219334,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 237665,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237729,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 222438,
            ["pct"] = 100,
        },
        ["TABARD"] = {
            ["itemID"] = 233288,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 215135,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 237567,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 242395,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 242396,
            ["pct"] = 100,
        },
    },
    ["SHAMAN_RESTORATION_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271483,
            ["pct"] = 45,
        },
        ["NECK"] = {
            ["itemID"] = 251234,
            ["pct"] = 27,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271481,
            ["pct"] = 82,
        },
        ["CHEST"] = {
            ["itemID"] = 271486,
            ["pct"] = 82,
        },
        ["WAIST"] = {
            ["itemID"] = 244581,
            ["pct"] = 18,
        },
        ["LEGS"] = {
            ["itemID"] = 249978,
            ["pct"] = 55,
        },
        ["FEET"] = {
            ["itemID"] = 251145,
            ["pct"] = 45,
        },
        ["WRIST"] = {
            ["itemID"] = 244584,
            ["pct"] = 55,
        },
        ["HANDS"] = {
            ["itemID"] = 271484,
            ["pct"] = 45,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 27,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 158369,
            ["pct"] = 18,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 237831,
            ["pct"] = 45,
        },
        ["FINGER_1"] = {
            ["itemID"] = 158366,
            ["pct"] = 27,
        },
        ["FINGER_2"] = {
            ["itemID"] = 273792,
            ["pct"] = 27,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 264507,
            ["pct"] = 36,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 270162,
            ["pct"] = 36,
        },
    },
    ["SHAMAN_RESTORATION_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 212011,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 212448,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 212009,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 212014,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 212414,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 212435,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 219335,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 219342,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 212012,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 225574,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222445,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 221073,
            ["pct"] = 100,
        },
        ["TABARD"] = {
            ["itemID"] = 69210,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 133287,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 215135,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 133304,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 178708,
            ["pct"] = 100,
        },
    },
    ["MAGE_FROST_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250060,
            ["pct"] = 67,
        },
        ["NECK"] = {
            ["itemID"] = 268291,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250058,
            ["pct"] = 33,
        },
        ["SHIRT"] = {
            ["itemID"] = 268274,
            ["pct"] = 33,
        },
        ["CHEST"] = {
            ["itemID"] = 250063,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 251185,
            ["pct"] = 33,
        },
        ["LEGS"] = {
            ["itemID"] = 250059,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 268282,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 239648,
            ["pct"] = 83,
        },
        ["HANDS"] = {
            ["itemID"] = 250061,
            ["pct"] = 83,
        },
        ["BACK"] = {
            ["itemID"] = 272230,
            ["pct"] = 33,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245770,
            ["pct"] = 67,
        },
        ["TABARD"] = {
            ["itemID"] = 64884,
            ["pct"] = 17,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 249922,
            ["pct"] = 17,
        },
        ["FINGER_1"] = {
            ["itemID"] = 193708,
            ["pct"] = 33,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251136,
            ["pct"] = 33,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 67,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249346,
            ["pct"] = 33,
        },
    },
    ["MAGE_FROST_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 211011,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 224594,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 178696,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 212095,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 221087,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 219178,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 219181,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 211014,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 212093,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 221088,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 211047,
            ["pct"] = 50,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 211041,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 211061,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 221136,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 219314,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 159622,
            ["pct"] = 50,
        },
    },
    ["MAGE_ARCANE_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250060,
            ["pct"] = 33,
        },
        ["NECK"] = {
            ["itemID"] = 50228,
            ["pct"] = 17,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271562,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 271567,
            ["pct"] = 67,
        },
        ["WAIST"] = {
            ["itemID"] = 251222,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 271563,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 159243,
            ["pct"] = 33,
        },
        ["WRIST"] = {
            ["itemID"] = 239648,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 271565,
            ["pct"] = 67,
        },
        ["BACK"] = {
            ["itemID"] = 251132,
            ["pct"] = 33,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 251188,
            ["pct"] = 33,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 245769,
            ["pct"] = 67,
        },
        ["SHIRT"] = {
            ["itemID"] = 268274,
            ["pct"] = 17,
        },
        ["FINGER_1"] = {
            ["itemID"] = 251148,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 158366,
            ["pct"] = 33,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249346,
            ["pct"] = 33,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250259,
            ["pct"] = 33,
        },
    },
    ["MAGE_ARCANE_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 153822,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 153815,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 153825,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 243500,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 243039,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 153823,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 153820,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 153827,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 153821,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 153830,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 153817,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 153818,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 153816,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 153819,
            ["pct"] = 100,
        },
    },
    ["PALADIN_HOLY_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 249961,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 251173,
            ["pct"] = 25,
        },
        ["SHOULDER"] = {
            ["itemID"] = 249959,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 271468,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 159442,
            ["pct"] = 33,
        },
        ["LEGS"] = {
            ["itemID"] = 249960,
            ["pct"] = 42,
        },
        ["FEET"] = {
            ["itemID"] = 159412,
            ["pct"] = 25,
        },
        ["WRIST"] = {
            ["itemID"] = 237834,
            ["pct"] = 33,
        },
        ["HANDS"] = {
            ["itemID"] = 271466,
            ["pct"] = 42,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 25,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237843,
            ["pct"] = 58,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 159664,
            ["pct"] = 17,
        },
        ["FINGER_1"] = {
            ["itemID"] = 159459,
            ["pct"] = 42,
        },
        ["FINGER_2"] = {
            ["itemID"] = 158366,
            ["pct"] = 25,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 273796,
            ["pct"] = 25,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250254,
            ["pct"] = 17,
        },
    },
    ["PALADIN_HOLY_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 237619,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 185820,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 221155,
            ["pct"] = 100,
        },
        ["SHIRT"] = {
            ["itemID"] = 52019,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 237622,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 234505,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 237618,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 185787,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 242475,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 237620,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222445,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 222432,
            ["pct"] = 100,
        },
        ["TABARD"] = {
            ["itemID"] = 52252,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 215135,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 221200,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 242393,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 242400,
            ["pct"] = 100,
        },
    },
    ["PALADIN_RETRIBUTION_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 249961,
            ["pct"] = 78,
        },
        ["NECK"] = {
            ["itemID"] = 268291,
            ["pct"] = 33,
        },
        ["SHOULDER"] = {
            ["itemID"] = 249959,
            ["pct"] = 67,
        },
        ["CHEST"] = {
            ["itemID"] = 249964,
            ["pct"] = 67,
        },
        ["WAIST"] = {
            ["itemID"] = 268289,
            ["pct"] = 78,
        },
        ["LEGS"] = {
            ["itemID"] = 249960,
            ["pct"] = 56,
        },
        ["FEET"] = {
            ["itemID"] = 249381,
            ["pct"] = 33,
        },
        ["WRIST"] = {
            ["itemID"] = 237834,
            ["pct"] = 33,
        },
        ["HANDS"] = {
            ["itemID"] = 271466,
            ["pct"] = 44,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 33,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237846,
            ["pct"] = 56,
        },
        ["TABARD"] = {
            ["itemID"] = 35280,
            ["pct"] = 11,
        },
        ["FINGER_1"] = {
            ["itemID"] = 252258,
            ["pct"] = 33,
        },
        ["FINGER_2"] = {
            ["itemID"] = 268290,
            ["pct"] = 33,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 193701,
            ["pct"] = 89,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249343,
            ["pct"] = 44,
        },
    },
    ["PALADIN_RETRIBUTION_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 211993,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 221060,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 211991,
            ["pct"] = 50,
        },
        ["SHIRT"] = {
            ["itemID"] = 24143,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 222430,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 221079,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 211992,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 211995,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 212437,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 211994,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 222817,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 178780,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 133286,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 228411,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 133300,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 219300,
            ["pct"] = 50,
        },
    },
    ["WARRIOR_ARMS_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271456,
            ["pct"] = 83,
        },
        ["NECK"] = {
            ["itemID"] = 273781,
            ["pct"] = 33,
        },
        ["SHOULDER"] = {
            ["itemID"] = 249950,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 271459,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 159418,
            ["pct"] = 33,
        },
        ["LEGS"] = {
            ["itemID"] = 271455,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 237828,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 237834,
            ["pct"] = 67,
        },
        ["HANDS"] = {
            ["itemID"] = 271457,
            ["pct"] = 83,
        },
        ["BACK"] = {
            ["itemID"] = 268248,
            ["pct"] = 33,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 251134,
            ["pct"] = 50,
        },
        ["TABARD"] = {
            ["itemID"] = 168100,
            ["pct"] = 17,
        },
        ["FINGER_1"] = {
            ["itemID"] = 49812,
            ["pct"] = 33,
        },
        ["FINGER_2"] = {
            ["itemID"] = 159459,
            ["pct"] = 33,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249342,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 274493,
            ["pct"] = 33,
        },
    },
    ["WARRIOR_ARMS_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 211984,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 178707,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 211982,
            ["pct"] = 100,
        },
        ["SHIRT"] = {
            ["itemID"] = 4335,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 211987,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 133289,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 219154,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 211986,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 222435,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 211985,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 133363,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222447,
            ["pct"] = 100,
        },
        ["TABARD"] = {
            ["itemID"] = 5976,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 159461,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 228411,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 133300,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 219311,
            ["pct"] = 100,
        },
    },
    ["WARRIOR_PROTECTION_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 249952,
            ["pct"] = 40,
        },
        ["NECK"] = {
            ["itemID"] = 251173,
            ["pct"] = 40,
        },
        ["SHOULDER"] = {
            ["itemID"] = 249950,
            ["pct"] = 60,
        },
        ["SHIRT"] = {
            ["itemID"] = 52019,
            ["pct"] = 20,
        },
        ["CHEST"] = {
            ["itemID"] = 271459,
            ["pct"] = 40,
        },
        ["WAIST"] = {
            ["itemID"] = 159418,
            ["pct"] = 20,
        },
        ["LEGS"] = {
            ["itemID"] = 249951,
            ["pct"] = 60,
        },
        ["FEET"] = {
            ["itemID"] = 273777,
            ["pct"] = 80,
        },
        ["WRIST"] = {
            ["itemID"] = 159425,
            ["pct"] = 40,
        },
        ["HANDS"] = {
            ["itemID"] = 251214,
            ["pct"] = 40,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 20,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 251195,
            ["pct"] = 40,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 237831,
            ["pct"] = 40,
        },
        ["FINGER_1"] = {
            ["itemID"] = 159459,
            ["pct"] = 40,
        },
        ["FINGER_2"] = {
            ["itemID"] = 273792,
            ["pct"] = 40,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 20,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250228,
            ["pct"] = 20,
        },
    },
    ["WARRIOR_PROTECTION_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 249952,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 268291,
            ["pct"] = 67,
        },
        ["SHOULDER"] = {
            ["itemID"] = 249950,
            ["pct"] = 100,
        },
        ["SHIRT"] = {
            ["itemID"] = 268274,
            ["pct"] = 33,
        },
        ["CHEST"] = {
            ["itemID"] = 249955,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 237830,
            ["pct"] = 33,
        },
        ["LEGS"] = {
            ["itemID"] = 249951,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 159412,
            ["pct"] = 33,
        },
        ["WRIST"] = {
            ["itemID"] = 237834,
            ["pct"] = 67,
        },
        ["HANDS"] = {
            ["itemID"] = 151332,
            ["pct"] = 33,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 33,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 249295,
            ["pct"] = 33,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 237831,
            ["pct"] = 67,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 67,
        },
        ["FINGER_2"] = {
            ["itemID"] = 49812,
            ["pct"] = 33,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249342,
            ["pct"] = 67,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249343,
            ["pct"] = 67,
        },
    },
    ["HUNTER_BEASTMASTERY_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271492,
            ["pct"] = 57,
        },
        ["NECK"] = {
            ["itemID"] = 251234,
            ["pct"] = 43,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271490,
            ["pct"] = 43,
        },
        ["CHEST"] = {
            ["itemID"] = 249991,
            ["pct"] = 43,
        },
        ["WAIST"] = {
            ["itemID"] = 251228,
            ["pct"] = 29,
        },
        ["LEGS"] = {
            ["itemID"] = 249987,
            ["pct"] = 57,
        },
        ["FEET"] = {
            ["itemID"] = 159388,
            ["pct"] = 29,
        },
        ["WRIST"] = {
            ["itemID"] = 244584,
            ["pct"] = 43,
        },
        ["HANDS"] = {
            ["itemID"] = 271493,
            ["pct"] = 57,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 14,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 265337,
            ["pct"] = 43,
        },
        ["TABARD"] = {
            ["itemID"] = 69210,
            ["pct"] = 14,
        },
        ["FINGER_1"] = {
            ["itemID"] = 158366,
            ["pct"] = 57,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251136,
            ["pct"] = 43,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 193701,
            ["pct"] = 43,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 273797,
            ["pct"] = 29,
        },
    },
    ["HUNTER_BEASTMASTERY_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 229271,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 215136,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 229269,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 229274,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 219339,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 229270,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 219335,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 219342,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 229272,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 222817,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 228893,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 228411,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 228840,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 230027,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 232541,
            ["pct"] = 100,
        },
    },
    ["HUNTER_MARKSMANSHIP_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271492,
            ["pct"] = 57,
        },
        ["NECK"] = {
            ["itemID"] = 268265,
            ["pct"] = 29,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271490,
            ["pct"] = 57,
        },
        ["CHEST"] = {
            ["itemID"] = 271495,
            ["pct"] = 57,
        },
        ["WAIST"] = {
            ["itemID"] = 244581,
            ["pct"] = 29,
        },
        ["LEGS"] = {
            ["itemID"] = 249987,
            ["pct"] = 57,
        },
        ["FEET"] = {
            ["itemID"] = 249990,
            ["pct"] = 57,
        },
        ["WRIST"] = {
            ["itemID"] = 244584,
            ["pct"] = 29,
        },
        ["HANDS"] = {
            ["itemID"] = 271493,
            ["pct"] = 57,
        },
        ["BACK"] = {
            ["itemID"] = 251132,
            ["pct"] = 43,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 265337,
            ["pct"] = 43,
        },
        ["FINGER_1"] = {
            ["itemID"] = 162544,
            ["pct"] = 29,
        },
        ["FINGER_2"] = {
            ["itemID"] = 193708,
            ["pct"] = 29,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 193701,
            ["pct"] = 57,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250228,
            ["pct"] = 29,
        },
    },
    ["HUNTER_MARKSMANSHIP_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 178738,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 212448,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 212018,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 212023,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 225580,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 212019,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 211022,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 212415,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 212021,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 222817,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 221969,
            ["pct"] = 100,
        },
        ["TABARD"] = {
            ["itemID"] = 198802,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 221136,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 225578,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 212454,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 212456,
            ["pct"] = 100,
        },
    },
    ["PRIEST_SHADOW_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271555,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 268291,
            ["pct"] = 33,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271553,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 271558,
            ["pct"] = 67,
        },
        ["WAIST"] = {
            ["itemID"] = 251185,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 271554,
            ["pct"] = 83,
        },
        ["FEET"] = {
            ["itemID"] = 251137,
            ["pct"] = 33,
        },
        ["WRIST"] = {
            ["itemID"] = 251127,
            ["pct"] = 67,
        },
        ["HANDS"] = {
            ["itemID"] = 250052,
            ["pct"] = 33,
        },
        ["BACK"] = {
            ["itemID"] = 239674,
            ["pct"] = 33,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 251123,
            ["pct"] = 33,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 245769,
            ["pct"] = 17,
        },
        ["FINGER_1"] = {
            ["itemID"] = 251136,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 252258,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 67,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249346,
            ["pct"] = 50,
        },
    },
    ["PRIEST_SHADOW_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 237709,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 185820,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 237707,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 237712,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 242664,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 237708,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 243305,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 222815,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 237710,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222568,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 178824,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 221200,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 242402,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 242497,
            ["pct"] = 100,
        },
    },
    ["ROGUE_SUBTLETY_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250006,
            ["pct"] = 38,
        },
        ["NECK"] = {
            ["itemID"] = 251142,
            ["pct"] = 25,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250004,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 271513,
            ["pct"] = 38,
        },
        ["WAIST"] = {
            ["itemID"] = 159317,
            ["pct"] = 25,
        },
        ["LEGS"] = {
            ["itemID"] = 250005,
            ["pct"] = 38,
        },
        ["FEET"] = {
            ["itemID"] = 251153,
            ["pct"] = 38,
        },
        ["WRIST"] = {
            ["itemID"] = 251183,
            ["pct"] = 38,
        },
        ["HANDS"] = {
            ["itemID"] = 271511,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 38,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237837,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 271093,
            ["pct"] = 25,
        },
        ["SHIRT"] = {
            ["itemID"] = 3428,
            ["pct"] = 13,
        },
        ["TABARD"] = {
            ["itemID"] = 43300,
            ["pct"] = 13,
        },
        ["FINGER_1"] = {
            ["itemID"] = 251148,
            ["pct"] = 38,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251136,
            ["pct"] = 25,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 250259,
            ["pct"] = 38,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249343,
            ["pct"] = 25,
        },
    },
    ["ROGUE_SUBTLETY_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 250006,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 268291,
            ["pct"] = 80,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250004,
            ["pct"] = 60,
        },
        ["CHEST"] = {
            ["itemID"] = 250009,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 268286,
            ["pct"] = 60,
        },
        ["LEGS"] = {
            ["itemID"] = 250005,
            ["pct"] = 60,
        },
        ["FEET"] = {
            ["itemID"] = 159304,
            ["pct"] = 20,
        },
        ["WRIST"] = {
            ["itemID"] = 250002,
            ["pct"] = 40,
        },
        ["HANDS"] = {
            ["itemID"] = 250007,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 239656,
            ["pct"] = 40,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237837,
            ["pct"] = 40,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 237837,
            ["pct"] = 40,
        },
        ["SHIRT"] = {
            ["itemID"] = 268274,
            ["pct"] = 20,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 249369,
            ["pct"] = 40,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249344,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249343,
            ["pct"] = 60,
        },
    },
    ["DRUID_FERAL_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250024,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 251142,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 273774,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 250027,
            ["pct"] = 75,
        },
        ["WAIST"] = {
            ["itemID"] = 251235,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 250023,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 159327,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 244576,
            ["pct"] = 75,
        },
        ["HANDS"] = {
            ["itemID"] = 250025,
            ["pct"] = 75,
        },
        ["BACK"] = {
            ["itemID"] = 251190,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 273783,
            ["pct"] = 50,
        },
        ["SHIRT"] = {
            ["itemID"] = 41248,
            ["pct"] = 25,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251115,
            ["pct"] = 25,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 193701,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 248583,
            ["pct"] = 25,
        },
    },
    ["DRUID_FERAL_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 212056,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 221077,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 212054,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 212059,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 225723,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 127249,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 221169,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 219334,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 151403,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 211005,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222448,
            ["pct"] = 50,
        },
        ["TABARD"] = {
            ["itemID"] = 233288,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 178736,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 221189,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 219314,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 225638,
            ["pct"] = 50,
        },
    },
    ["DRUID_GUARDIAN_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 193751,
            ["pct"] = 36,
        },
        ["NECK"] = {
            ["itemID"] = 273781,
            ["pct"] = 45,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271526,
            ["pct"] = 36,
        },
        ["CHEST"] = {
            ["itemID"] = 271531,
            ["pct"] = 27,
        },
        ["WAIST"] = {
            ["itemID"] = 159301,
            ["pct"] = 55,
        },
        ["LEGS"] = {
            ["itemID"] = 250023,
            ["pct"] = 36,
        },
        ["FEET"] = {
            ["itemID"] = 251153,
            ["pct"] = 36,
        },
        ["WRIST"] = {
            ["itemID"] = 244576,
            ["pct"] = 27,
        },
        ["HANDS"] = {
            ["itemID"] = 159337,
            ["pct"] = 27,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 36,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245771,
            ["pct"] = 27,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 27,
        },
        ["FINGER_2"] = {
            ["itemID"] = 151311,
            ["pct"] = 18,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 250245,
            ["pct"] = 27,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 159617,
            ["pct"] = 18,
        },
    },
    ["DRUID_GUARDIAN_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 218524,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 212448,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 212054,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 212059,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 178699,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 212055,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 219327,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 178702,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 212057,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 133363,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 218721,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 159461,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 215135,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 215174,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 215178,
            ["pct"] = 50,
        },
    },
    ["DRUID_RESTORATION_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250024,
            ["pct"] = 82,
        },
        ["NECK"] = {
            ["itemID"] = 251142,
            ["pct"] = 36,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250022,
            ["pct"] = 64,
        },
        ["CHEST"] = {
            ["itemID"] = 250027,
            ["pct"] = 27,
        },
        ["WAIST"] = {
            ["itemID"] = 159317,
            ["pct"] = 18,
        },
        ["LEGS"] = {
            ["itemID"] = 250023,
            ["pct"] = 64,
        },
        ["FEET"] = {
            ["itemID"] = 251153,
            ["pct"] = 27,
        },
        ["WRIST"] = {
            ["itemID"] = 244576,
            ["pct"] = 36,
        },
        ["HANDS"] = {
            ["itemID"] = 250025,
            ["pct"] = 64,
        },
        ["BACK"] = {
            ["itemID"] = 159288,
            ["pct"] = 18,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 159137,
            ["pct"] = 18,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 245769,
            ["pct"] = 18,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 55,
        },
        ["FINGER_2"] = {
            ["itemID"] = 249920,
            ["pct"] = 27,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 55,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 268292,
            ["pct"] = 27,
        },
    },
    ["DRUID_RESTORATION_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 237682,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 178827,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 237680,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 237685,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 245964,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 237681,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 246274,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 219334,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 178832,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222568,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 178824,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 221141,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 190958,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 219312,
            ["pct"] = 100,
        },
    },
    ["WARLOCK_DESTRUCTION_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250042,
            ["pct"] = 29,
        },
        ["NECK"] = {
            ["itemID"] = 251096,
            ["pct"] = 29,
        },
        ["SHOULDER"] = {
            ["itemID"] = 239031,
            ["pct"] = 29,
        },
        ["CHEST"] = {
            ["itemID"] = 250045,
            ["pct"] = 43,
        },
        ["WAIST"] = {
            ["itemID"] = 250039,
            ["pct"] = 29,
        },
        ["LEGS"] = {
            ["itemID"] = 271545,
            ["pct"] = 57,
        },
        ["FEET"] = {
            ["itemID"] = 277794,
            ["pct"] = 29,
        },
        ["WRIST"] = {
            ["itemID"] = 239648,
            ["pct"] = 57,
        },
        ["HANDS"] = {
            ["itemID"] = 271547,
            ["pct"] = 57,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 29,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 273778,
            ["pct"] = 29,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 245769,
            ["pct"] = 29,
        },
        ["TABARD"] = {
            ["itemID"] = 5976,
            ["pct"] = 14,
        },
        ["FINGER_1"] = {
            ["itemID"] = 273792,
            ["pct"] = 43,
        },
        ["FINGER_2"] = {
            ["itemID"] = 158366,
            ["pct"] = 29,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 57,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249346,
            ["pct"] = 29,
        },
    },
    ["WARLOCK_DESTRUCTION_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 237700,
            ["pct"] = 67,
        },
        ["NECK"] = {
            ["itemID"] = 185842,
            ["pct"] = 33,
        },
        ["SHOULDER"] = {
            ["itemID"] = 237698,
            ["pct"] = 67,
        },
        ["SHIRT"] = {
            ["itemID"] = 4330,
            ["pct"] = 33,
        },
        ["CHEST"] = {
            ["itemID"] = 237703,
            ["pct"] = 67,
        },
        ["WAIST"] = {
            ["itemID"] = 242664,
            ["pct"] = 67,
        },
        ["LEGS"] = {
            ["itemID"] = 237699,
            ["pct"] = 67,
        },
        ["FEET"] = {
            ["itemID"] = 228879,
            ["pct"] = 33,
        },
        ["WRIST"] = {
            ["itemID"] = 222815,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 237549,
            ["pct"] = 67,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 67,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 185822,
            ["pct"] = 33,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 222566,
            ["pct"] = 33,
        },
        ["TABARD"] = {
            ["itemID"] = 198732,
            ["pct"] = 33,
        },
        ["FINGER_1"] = {
            ["itemID"] = 178872,
            ["pct"] = 33,
        },
        ["FINGER_2"] = {
            ["itemID"] = 215135,
            ["pct"] = 33,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 242497,
            ["pct"] = 67,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 219296,
            ["pct"] = 33,
        },
    },
    ["PRIEST_HOLY_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250051,
            ["pct"] = 33,
        },
        ["NECK"] = {
            ["itemID"] = 251234,
            ["pct"] = 33,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250049,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 250054,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 251185,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 250050,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 251137,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 159263,
            ["pct"] = 33,
        },
        ["HANDS"] = {
            ["itemID"] = 250052,
            ["pct"] = 33,
        },
        ["BACK"] = {
            ["itemID"] = 159288,
            ["pct"] = 17,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245770,
            ["pct"] = 67,
        },
        ["FINGER_1"] = {
            ["itemID"] = 273792,
            ["pct"] = 67,
        },
        ["FINGER_2"] = {
            ["itemID"] = 268290,
            ["pct"] = 33,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 33,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 268292,
            ["pct"] = 33,
        },
    },
    ["PRIEST_HOLY_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 250051,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 50228,
            ["pct"] = 25,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250049,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 250054,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 151302,
            ["pct"] = 25,
        },
        ["LEGS"] = {
            ["itemID"] = 250050,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 151301,
            ["pct"] = 25,
        },
        ["WRIST"] = {
            ["itemID"] = 239648,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 250052,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 193712,
            ["pct"] = 25,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245770,
            ["pct"] = 25,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 249922,
            ["pct"] = 25,
        },
        ["TABARD"] = {
            ["itemID"] = 168100,
            ["pct"] = 25,
        },
        ["SHIRT"] = {
            ["itemID"] = 268274,
            ["pct"] = 25,
        },
        ["FINGER_1"] = {
            ["itemID"] = 193708,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 151308,
            ["pct"] = 25,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 251792,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 193718,
            ["pct"] = 25,
        },
    },
    ["MAGE_FIRE_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250060,
            ["pct"] = 75,
        },
        ["NECK"] = {
            ["itemID"] = 250247,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250058,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 268284,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 193691,
            ["pct"] = 25,
        },
        ["LEGS"] = {
            ["itemID"] = 250059,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 251137,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 239648,
            ["pct"] = 75,
        },
        ["HANDS"] = {
            ["itemID"] = 250061,
            ["pct"] = 75,
        },
        ["BACK"] = {
            ["itemID"] = 159288,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 159636,
            ["pct"] = 25,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 245769,
            ["pct"] = 50,
        },
        ["TABARD"] = {
            ["itemID"] = 45585,
            ["pct"] = 25,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 75,
        },
        ["FINGER_2"] = {
            ["itemID"] = 272150,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 250144,
            ["pct"] = 75,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 273796,
            ["pct"] = 50,
        },
    },
    ["MAGE_FIRE_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 237718,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 242406,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 243505,
            ["pct"] = 100,
        },
        ["SHIRT"] = {
            ["itemID"] = 3428,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 234496,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 242664,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 237717,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 237556,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 237558,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 237719,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237790,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 243548,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 178824,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 237959,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 156458,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 242398,
            ["pct"] = 100,
        },
    },
    ["DEATHKNIGHT_BLOOD_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271474,
            ["pct"] = 36,
        },
        ["NECK"] = {
            ["itemID"] = 251142,
            ["pct"] = 27,
        },
        ["SHOULDER"] = {
            ["itemID"] = 251138,
            ["pct"] = 36,
        },
        ["CHEST"] = {
            ["itemID"] = 273787,
            ["pct"] = 36,
        },
        ["WAIST"] = {
            ["itemID"] = 159442,
            ["pct"] = 27,
        },
        ["LEGS"] = {
            ["itemID"] = 159435,
            ["pct"] = 27,
        },
        ["FEET"] = {
            ["itemID"] = 159412,
            ["pct"] = 18,
        },
        ["WRIST"] = {
            ["itemID"] = 159425,
            ["pct"] = 45,
        },
        ["HANDS"] = {
            ["itemID"] = 159413,
            ["pct"] = 36,
        },
        ["BACK"] = {
            ["itemID"] = 159288,
            ["pct"] = 36,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237846,
            ["pct"] = 73,
        },
        ["TABARD"] = {
            ["itemID"] = 224165,
            ["pct"] = 9,
        },
        ["FINGER_1"] = {
            ["itemID"] = 252258,
            ["pct"] = 45,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251194,
            ["pct"] = 36,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 159618,
            ["pct"] = 18,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 193762,
            ["pct"] = 18,
        },
    },
    ["DEATHKNIGHT_BLOOD_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 212002,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 215136,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 212000,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 212005,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 212442,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 212001,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 212004,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 222435,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 212003,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 225574,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222447,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 212447,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 228411,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 212449,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 219915,
            ["pct"] = 100,
        },
    },
    ["DEATHKNIGHT_FROST_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 249970,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 251234,
            ["pct"] = 67,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271472,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 249973,
            ["pct"] = 67,
        },
        ["WAIST"] = {
            ["itemID"] = 159418,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 249969,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 193728,
            ["pct"] = 33,
        },
        ["WRIST"] = {
            ["itemID"] = 159409,
            ["pct"] = 33,
        },
        ["HANDS"] = {
            ["itemID"] = 249971,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 159288,
            ["pct"] = 33,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237839,
            ["pct"] = 83,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 158373,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 193708,
            ["pct"] = 33,
        },
        ["FINGER_2"] = {
            ["itemID"] = 240949,
            ["pct"] = 33,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 250238,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250229,
            ["pct"] = 33,
        },
    },
    ["DEATHKNIGHT_FROST_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 237628,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 242406,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 237626,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 237631,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 245966,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 237627,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 221123,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 222435,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 237629,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222447,
            ["pct"] = 100,
        },
        ["TABARD"] = {
            ["itemID"] = 233288,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 215135,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 237958,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 242394,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 246344,
            ["pct"] = 100,
        },
    },
    ["ROGUE_OUTLAW_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271510,
            ["pct"] = 60,
        },
        ["NECK"] = {
            ["itemID"] = 273781,
            ["pct"] = 30,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271508,
            ["pct"] = 50,
        },
        ["SHIRT"] = {
            ["itemID"] = 138385,
            ["pct"] = 10,
        },
        ["CHEST"] = {
            ["itemID"] = 271513,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 268286,
            ["pct"] = 40,
        },
        ["LEGS"] = {
            ["itemID"] = 271509,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 244569,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 251135,
            ["pct"] = 40,
        },
        ["HANDS"] = {
            ["itemID"] = 271511,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 30,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237839,
            ["pct"] = 60,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 193767,
            ["pct"] = 30,
        },
        ["TABARD"] = {
            ["itemID"] = 5976,
            ["pct"] = 10,
        },
        ["FINGER_1"] = {
            ["itemID"] = 251148,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 273792,
            ["pct"] = 40,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250259,
            ["pct"] = 30,
        },
    },
    ["ROGUE_OUTLAW_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 239033,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 251173,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250004,
            ["pct"] = 50,
        },
        ["SHIRT"] = {
            ["itemID"] = 167179,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 239048,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 159301,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 251198,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 251153,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 50264,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 193758,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 239656,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 159645,
            ["pct"] = 50,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 158714,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 249336,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 268290,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250214,
            ["pct"] = 50,
        },
    },
    ["SHAMAN_ELEMENTAL_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271483,
            ["pct"] = 70,
        },
        ["NECK"] = {
            ["itemID"] = 251234,
            ["pct"] = 40,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271481,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 271486,
            ["pct"] = 30,
        },
        ["WAIST"] = {
            ["itemID"] = 251228,
            ["pct"] = 30,
        },
        ["LEGS"] = {
            ["itemID"] = 249978,
            ["pct"] = 40,
        },
        ["FEET"] = {
            ["itemID"] = 244577,
            ["pct"] = 40,
        },
        ["WRIST"] = {
            ["itemID"] = 244584,
            ["pct"] = 70,
        },
        ["HANDS"] = {
            ["itemID"] = 271484,
            ["pct"] = 60,
        },
        ["BACK"] = {
            ["itemID"] = 251132,
            ["pct"] = 30,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 193761,
            ["pct"] = 20,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 159664,
            ["pct"] = 10,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 40,
        },
        ["FINGER_2"] = {
            ["itemID"] = 273792,
            ["pct"] = 40,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 250215,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249343,
            ["pct"] = 30,
        },
    },
    ["SHAMAN_ELEMENTAL_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 153977,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 153968,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 153980,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 153974,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 153981,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 153978,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 153975,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 153982,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 153976,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 153998,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 153973,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 153979,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 153970,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 153971,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 153969,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 153972,
            ["pct"] = 100,
        },
    },
    ["WARLOCK_AFFLICTION_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250042,
            ["pct"] = 40,
        },
        ["NECK"] = {
            ["itemID"] = 251142,
            ["pct"] = 20,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250040,
            ["pct"] = 40,
        },
        ["CHEST"] = {
            ["itemID"] = 250045,
            ["pct"] = 80,
        },
        ["WAIST"] = {
            ["itemID"] = 193691,
            ["pct"] = 20,
        },
        ["LEGS"] = {
            ["itemID"] = 250041,
            ["pct"] = 60,
        },
        ["FEET"] = {
            ["itemID"] = 159243,
            ["pct"] = 20,
        },
        ["WRIST"] = {
            ["itemID"] = 239648,
            ["pct"] = 60,
        },
        ["HANDS"] = {
            ["itemID"] = 250043,
            ["pct"] = 80,
        },
        ["BACK"] = {
            ["itemID"] = 159288,
            ["pct"] = 20,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245770,
            ["pct"] = 40,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 159667,
            ["pct"] = 20,
        },
        ["SHIRT"] = {
            ["itemID"] = 268274,
            ["pct"] = 20,
        },
        ["FINGER_1"] = {
            ["itemID"] = 252258,
            ["pct"] = 40,
        },
        ["FINGER_2"] = {
            ["itemID"] = 268290,
            ["pct"] = 40,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 60,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250144,
            ["pct"] = 40,
        },
    },
    ["WARLOCK_AFFLICTION_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 229325,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 215136,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 229323,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 229328,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 242664,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 229324,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 222814,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 222815,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 222822,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 222817,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222568,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 221099,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 231265,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 230027,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 230192,
            ["pct"] = 100,
        },
    },
    ["WARLOCK_DEMONOLOGY_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250042,
            ["pct"] = 60,
        },
        ["NECK"] = {
            ["itemID"] = 251234,
            ["pct"] = 30,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250040,
            ["pct"] = 30,
        },
        ["CHEST"] = {
            ["itemID"] = 271549,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 250039,
            ["pct"] = 30,
        },
        ["LEGS"] = {
            ["itemID"] = 250041,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 251219,
            ["pct"] = 40,
        },
        ["WRIST"] = {
            ["itemID"] = 239648,
            ["pct"] = 40,
        },
        ["HANDS"] = {
            ["itemID"] = 250043,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 239656,
            ["pct"] = 30,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245770,
            ["pct"] = 40,
        },
        ["SHIRT"] = {
            ["itemID"] = 268274,
            ["pct"] = 20,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 245769,
            ["pct"] = 30,
        },
        ["TABARD"] = {
            ["itemID"] = 35279,
            ["pct"] = 10,
        },
        ["FINGER_1"] = {
            ["itemID"] = 251217,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251093,
            ["pct"] = 20,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 250144,
            ["pct"] = 80,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249343,
            ["pct"] = 40,
        },
    },
    ["WARLOCK_DEMONOLOGY_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 229325,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 215136,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 229323,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 229328,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 222816,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 229324,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 222814,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 221104,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 229326,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 222817,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 178789,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 222566,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 178869,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 228411,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 219308,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 230192,
            ["pct"] = 100,
        },
    },
    ["MONK_WINDWALKER_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250015,
            ["pct"] = 43,
        },
        ["NECK"] = {
            ["itemID"] = 268291,
            ["pct"] = 43,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250013,
            ["pct"] = 43,
        },
        ["CHEST"] = {
            ["itemID"] = 271522,
            ["pct"] = 43,
        },
        ["WAIST"] = {
            ["itemID"] = 251235,
            ["pct"] = 29,
        },
        ["LEGS"] = {
            ["itemID"] = 271518,
            ["pct"] = 29,
        },
        ["FEET"] = {
            ["itemID"] = 244569,
            ["pct"] = 43,
        },
        ["WRIST"] = {
            ["itemID"] = 244576,
            ["pct"] = 29,
        },
        ["HANDS"] = {
            ["itemID"] = 250016,
            ["pct"] = 43,
        },
        ["BACK"] = {
            ["itemID"] = 272230,
            ["pct"] = 29,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 158714,
            ["pct"] = 14,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 159645,
            ["pct"] = 14,
        },
        ["SHIRT"] = {
            ["itemID"] = 41248,
            ["pct"] = 14,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 43,
        },
        ["FINGER_2"] = {
            ["itemID"] = 158366,
            ["pct"] = 29,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 193701,
            ["pct"] = 57,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249343,
            ["pct"] = 29,
        },
    },
    ["MONK_WINDWALKER_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 221802,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 225577,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 212045,
            ["pct"] = 100,
        },
        ["SHIRT"] = {
            ["itemID"] = 2576,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 212050,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 212044,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 212046,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 212445,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 212043,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 212048,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 225574,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 212409,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 222451,
            ["pct"] = 100,
        },
        ["TABARD"] = {
            ["itemID"] = 5976,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 215135,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 225578,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 219314,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 221023,
            ["pct"] = 100,
        },
    },
    ["DRUID_BALANCE_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271528,
            ["pct"] = 64,
        },
        ["NECK"] = {
            ["itemID"] = 251173,
            ["pct"] = 27,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250022,
            ["pct"] = 45,
        },
        ["SHIRT"] = {
            ["itemID"] = 2577,
            ["pct"] = 9,
        },
        ["CHEST"] = {
            ["itemID"] = 271531,
            ["pct"] = 64,
        },
        ["WAIST"] = {
            ["itemID"] = 268286,
            ["pct"] = 36,
        },
        ["LEGS"] = {
            ["itemID"] = 271527,
            ["pct"] = 36,
        },
        ["FEET"] = {
            ["itemID"] = 159304,
            ["pct"] = 36,
        },
        ["WRIST"] = {
            ["itemID"] = 251183,
            ["pct"] = 36,
        },
        ["HANDS"] = {
            ["itemID"] = 271529,
            ["pct"] = 45,
        },
        ["BACK"] = {
            ["itemID"] = 251132,
            ["pct"] = 36,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 251225,
            ["pct"] = 36,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 245769,
            ["pct"] = 64,
        },
        ["TABARD"] = {
            ["itemID"] = 274451,
            ["pct"] = 9,
        },
        ["FINGER_1"] = {
            ["itemID"] = 252258,
            ["pct"] = 45,
        },
        ["FINGER_2"] = {
            ["itemID"] = 268290,
            ["pct"] = 27,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 273796,
            ["pct"] = 73,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250214,
            ["pct"] = 27,
        },
    },
    ["DRUID_BALANCE_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 212056,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 225577,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 212054,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 212059,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 225583,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 212055,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 219327,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 212438,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 212057,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 212446,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222568,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 133286,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 225576,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 178708,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 220202,
            ["pct"] = 100,
        },
    },
    ["DEMONHUNTER_HAVOC_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271537,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 268291,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250031,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 271540,
            ["pct"] = 63,
        },
        ["WAIST"] = {
            ["itemID"] = 251235,
            ["pct"] = 38,
        },
        ["LEGS"] = {
            ["itemID"] = 271536,
            ["pct"] = 75,
        },
        ["FEET"] = {
            ["itemID"] = 159327,
            ["pct"] = 38,
        },
        ["WRIST"] = {
            ["itemID"] = 244576,
            ["pct"] = 63,
        },
        ["HANDS"] = {
            ["itemID"] = 250034,
            ["pct"] = 38,
        },
        ["BACK"] = {
            ["itemID"] = 251132,
            ["pct"] = 38,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237840,
            ["pct"] = 75,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 237840,
            ["pct"] = 25,
        },
        ["SHIRT"] = {
            ["itemID"] = 268274,
            ["pct"] = 25,
        },
        ["FINGER_1"] = {
            ["itemID"] = 158366,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 193708,
            ["pct"] = 38,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 63,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 193701,
            ["pct"] = 50,
        },
    },
    ["DEMONHUNTER_HAVOC_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 237691,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 246190,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 237689,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 237973,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 245964,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 237690,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 237974,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 219334,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 237692,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 234491,
            ["pct"] = 50,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 222441,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 178824,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 221136,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 190958,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 232541,
            ["pct"] = 50,
        },
    },
    ["DEMONHUNTER_VENGEANCE_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250033,
            ["pct"] = 31,
        },
        ["NECK"] = {
            ["itemID"] = 273781,
            ["pct"] = 31,
        },
        ["SHOULDER"] = {
            ["itemID"] = 251223,
            ["pct"] = 31,
        },
        ["CHEST"] = {
            ["itemID"] = 250036,
            ["pct"] = 46,
        },
        ["WAIST"] = {
            ["itemID"] = 251235,
            ["pct"] = 31,
        },
        ["LEGS"] = {
            ["itemID"] = 250032,
            ["pct"] = 31,
        },
        ["FEET"] = {
            ["itemID"] = 251153,
            ["pct"] = 38,
        },
        ["WRIST"] = {
            ["itemID"] = 159300,
            ["pct"] = 31,
        },
        ["HANDS"] = {
            ["itemID"] = 159312,
            ["pct"] = 23,
        },
        ["BACK"] = {
            ["itemID"] = 251190,
            ["pct"] = 23,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237840,
            ["pct"] = 77,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 237840,
            ["pct"] = 23,
        },
        ["TABARD"] = {
            ["itemID"] = 38313,
            ["pct"] = 8,
        },
        ["FINGER_1"] = {
            ["itemID"] = 252258,
            ["pct"] = 23,
        },
        ["FINGER_2"] = {
            ["itemID"] = 268290,
            ["pct"] = 23,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 250245,
            ["pct"] = 23,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 158374,
            ["pct"] = 15,
        },
    },
    ["DEMONHUNTER_VENGEANCE_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 240775,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 246190,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 247031,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 247069,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 247637,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 247156,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 247440,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 247604,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 247528,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 247491,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 242577,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 242576,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 246197,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 246201,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 246207,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 246208,
            ["pct"] = 100,
        },
    },
    ["EVOKER_DEVASTATION_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271501,
            ["pct"] = 75,
        },
        ["NECK"] = {
            ["itemID"] = 251234,
            ["pct"] = 38,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271499,
            ["pct"] = 63,
        },
        ["SHIRT"] = {
            ["itemID"] = 268274,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 271504,
            ["pct"] = 38,
        },
        ["WAIST"] = {
            ["itemID"] = 49810,
            ["pct"] = 38,
        },
        ["LEGS"] = {
            ["itemID"] = 249996,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 249999,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 244584,
            ["pct"] = 63,
        },
        ["HANDS"] = {
            ["itemID"] = 271502,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 159288,
            ["pct"] = 25,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 268210,
            ["pct"] = 25,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 245769,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 63,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251136,
            ["pct"] = 25,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249346,
            ["pct"] = 63,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 273796,
            ["pct"] = 25,
        },
    },
    ["EVOKER_DEVASTATION_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 212029,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 215136,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 212027,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 212421,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 219339,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 212028,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 219335,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 212415,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 212030,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 156050,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222568,
            ["pct"] = 100,
        },
        ["TABARD"] = {
            ["itemID"] = 198732,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 228411,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 162541,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 178708,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 219308,
            ["pct"] = 50,
        },
    },
    ["EVOKER_PRESERVATION_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 249997,
            ["pct"] = 43,
        },
        ["NECK"] = {
            ["itemID"] = 268291,
            ["pct"] = 43,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271499,
            ["pct"] = 57,
        },
        ["CHEST"] = {
            ["itemID"] = 250000,
            ["pct"] = 29,
        },
        ["WAIST"] = {
            ["itemID"] = 244581,
            ["pct"] = 29,
        },
        ["LEGS"] = {
            ["itemID"] = 271500,
            ["pct"] = 43,
        },
        ["FEET"] = {
            ["itemID"] = 159388,
            ["pct"] = 14,
        },
        ["WRIST"] = {
            ["itemID"] = 277772,
            ["pct"] = 43,
        },
        ["HANDS"] = {
            ["itemID"] = 271502,
            ["pct"] = 43,
        },
        ["BACK"] = {
            ["itemID"] = 251190,
            ["pct"] = 29,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245770,
            ["pct"] = 29,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 245769,
            ["pct"] = 29,
        },
        ["TABARD"] = {
            ["itemID"] = 194675,
            ["pct"] = 14,
        },
        ["FINGER_1"] = {
            ["itemID"] = 158366,
            ["pct"] = 29,
        },
        ["FINGER_2"] = {
            ["itemID"] = 162544,
            ["pct"] = 29,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 29,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249809,
            ["pct"] = 29,
        },
    },
    ["EVOKER_PRESERVATION_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 223293,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 221060,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 223291,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 219166,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 211027,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 224686,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 224683,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 223403,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 211023,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 211005,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 224705,
            ["pct"] = 100,
        },
        ["TABARD"] = {
            ["itemID"] = 194675,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 219189,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 224662,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 225651,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 225656,
            ["pct"] = 100,
        },
    },
    ["EVOKER_AUGMENTATION_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 193765,
            ["pct"] = 29,
        },
        ["NECK"] = {
            ["itemID"] = 251234,
            ["pct"] = 57,
        },
        ["SHOULDER"] = {
            ["itemID"] = 249995,
            ["pct"] = 43,
        },
        ["CHEST"] = {
            ["itemID"] = 250000,
            ["pct"] = 57,
        },
        ["WAIST"] = {
            ["itemID"] = 159369,
            ["pct"] = 29,
        },
        ["LEGS"] = {
            ["itemID"] = 249996,
            ["pct"] = 57,
        },
        ["FEET"] = {
            ["itemID"] = 249999,
            ["pct"] = 43,
        },
        ["WRIST"] = {
            ["itemID"] = 244584,
            ["pct"] = 86,
        },
        ["HANDS"] = {
            ["itemID"] = 249998,
            ["pct"] = 43,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 43,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 273778,
            ["pct"] = 29,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 245769,
            ["pct"] = 29,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 57,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251136,
            ["pct"] = 29,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 250223,
            ["pct"] = 57,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250224,
            ["pct"] = 29,
        },
    },
    ["EVOKER_AUGMENTATION_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 212029,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 178707,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 212027,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 212032,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 221168,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 212028,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 159379,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 159372,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 212030,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 133363,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222568,
            ["pct"] = 100,
        },
        ["TABARD"] = {
            ["itemID"] = 194675,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 162541,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 215133,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 178708,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 219314,
            ["pct"] = 100,
        },
    },
    ["DEMONHUNTER_DEVOURER_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271537,
            ["pct"] = 55,
        },
        ["NECK"] = {
            ["itemID"] = 251142,
            ["pct"] = 55,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271535,
            ["pct"] = 45,
        },
        ["CHEST"] = {
            ["itemID"] = 271540,
            ["pct"] = 55,
        },
        ["WAIST"] = {
            ["itemID"] = 268286,
            ["pct"] = 27,
        },
        ["LEGS"] = {
            ["itemID"] = 271536,
            ["pct"] = 55,
        },
        ["FEET"] = {
            ["itemID"] = 251153,
            ["pct"] = 36,
        },
        ["WRIST"] = {
            ["itemID"] = 244576,
            ["pct"] = 27,
        },
        ["HANDS"] = {
            ["itemID"] = 271538,
            ["pct"] = 45,
        },
        ["BACK"] = {
            ["itemID"] = 251132,
            ["pct"] = 36,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237840,
            ["pct"] = 82,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 237840,
            ["pct"] = 18,
        },
        ["SHIRT"] = {
            ["itemID"] = 4336,
            ["pct"] = 9,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 55,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251136,
            ["pct"] = 27,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249346,
            ["pct"] = 45,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249343,
            ["pct"] = 36,
        },
    },
    ["DEMONHUNTER_DEVOURER_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 250033,
            ["pct"] = 80,
        },
        ["NECK"] = {
            ["itemID"] = 268291,
            ["pct"] = 40,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250031,
            ["pct"] = 60,
        },
        ["SHIRT"] = {
            ["itemID"] = 41255,
            ["pct"] = 20,
        },
        ["CHEST"] = {
            ["itemID"] = 250036,
            ["pct"] = 40,
        },
        ["WAIST"] = {
            ["itemID"] = 244573,
            ["pct"] = 40,
        },
        ["LEGS"] = {
            ["itemID"] = 250032,
            ["pct"] = 40,
        },
        ["FEET"] = {
            ["itemID"] = 250035,
            ["pct"] = 40,
        },
        ["WRIST"] = {
            ["itemID"] = 193714,
            ["pct"] = 60,
        },
        ["HANDS"] = {
            ["itemID"] = 250034,
            ["pct"] = 60,
        },
        ["BACK"] = {
            ["itemID"] = 250028,
            ["pct"] = 40,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237840,
            ["pct"] = 80,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 237840,
            ["pct"] = 40,
        },
        ["TABARD"] = {
            ["itemID"] = 5976,
            ["pct"] = 20,
        },
        ["FINGER_1"] = {
            ["itemID"] = 251115,
            ["pct"] = 60,
        },
        ["FINGER_2"] = {
            ["itemID"] = 268290,
            ["pct"] = 40,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 80,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250144,
            ["pct"] = 40,
        },
    },
}
