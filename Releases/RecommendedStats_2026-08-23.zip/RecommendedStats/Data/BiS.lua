-- GENERATED 2026-08-23 - do not hand-edit
RecommendedStatsData_BiS = {
    ["SHAMAN_ENHANCEMENT_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271483,
            ["pct"] = 67,
        },
        ["NECK"] = {
            ["itemID"] = 273781,
            ["pct"] = 33,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271481,
            ["pct"] = 67,
        },
        ["CHEST"] = {
            ["itemID"] = 271486,
            ["pct"] = 67,
        },
        ["WAIST"] = {
            ["itemID"] = 251155,
            ["pct"] = 33,
        },
        ["LEGS"] = {
            ["itemID"] = 271482,
            ["pct"] = 67,
        },
        ["FEET"] = {
            ["itemID"] = 251145,
            ["pct"] = 33,
        },
        ["WRIST"] = {
            ["itemID"] = 244584,
            ["pct"] = 33,
        },
        ["HANDS"] = {
            ["itemID"] = 271484,
            ["pct"] = 33,
        },
        ["BACK"] = {
            ["itemID"] = 251132,
            ["pct"] = 33,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237850,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 251224,
            ["pct"] = 44,
        },
        ["SHIRT"] = {
            ["itemID"] = 10034,
            ["pct"] = 11,
        },
        ["FINGER_1"] = {
            ["itemID"] = 252258,
            ["pct"] = 56,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251194,
            ["pct"] = 33,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 193701,
            ["pct"] = 44,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249343,
            ["pct"] = 33,
        },
    },
    ["SHAMAN_ENHANCEMENT_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 247035,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 246190,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 247041,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 247546,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 247537,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 240302,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 247578,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 240300,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 247564,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 247489,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 242567,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 242589,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 245997,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 246199,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 245999,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 246000,
            ["pct"] = 100,
        },
    },
    ["MONK_MISTWEAVER_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250015,
            ["pct"] = 40,
        },
        ["NECK"] = {
            ["itemID"] = 273781,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271517,
            ["pct"] = 40,
        },
        ["CHEST"] = {
            ["itemID"] = 271522,
            ["pct"] = 60,
        },
        ["WAIST"] = {
            ["itemID"] = 159301,
            ["pct"] = 40,
        },
        ["LEGS"] = {
            ["itemID"] = 271518,
            ["pct"] = 40,
        },
        ["FEET"] = {
            ["itemID"] = 159304,
            ["pct"] = 30,
        },
        ["WRIST"] = {
            ["itemID"] = 244576,
            ["pct"] = 30,
        },
        ["HANDS"] = {
            ["itemID"] = 250016,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 30,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245770,
            ["pct"] = 90,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 40,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251148,
            ["pct"] = 30,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249808,
            ["pct"] = 80,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249343,
            ["pct"] = 20,
        },
    },
    ["MONK_MISTWEAVER_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 229298,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 185820,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 229296,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 229301,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 245964,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 221114,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 219327,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 219334,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 229299,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 185841,
            ["pct"] = 50,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 222566,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 228840,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 215135,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 219312,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 230186,
            ["pct"] = 50,
        },
    },
    ["PALADIN_PROTECTION_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271465,
            ["pct"] = 40,
        },
        ["NECK"] = {
            ["itemID"] = 273781,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271463,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 249964,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 251144,
            ["pct"] = 30,
        },
        ["LEGS"] = {
            ["itemID"] = 249960,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 273777,
            ["pct"] = 40,
        },
        ["WRIST"] = {
            ["itemID"] = 159409,
            ["pct"] = 40,
        },
        ["HANDS"] = {
            ["itemID"] = 271466,
            ["pct"] = 40,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 40,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 158373,
            ["pct"] = 30,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 237831,
            ["pct"] = 80,
        },
        ["TABARD"] = {
            ["itemID"] = 168100,
            ["pct"] = 10,
        },
        ["FINGER_1"] = {
            ["itemID"] = 273792,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 158366,
            ["pct"] = 20,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 193762,
            ["pct"] = 30,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 273796,
            ["pct"] = 30,
        },
    },
    ["PALADIN_PROTECTION_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 228858,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 242406,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 237617,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 229247,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 245966,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 237618,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 243307,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 222435,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 229245,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237813,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 228889,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 185813,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 221141,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 230198,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 230199,
            ["pct"] = 100,
        },
    },
    ["HUNTER_SURVIVAL_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271492,
            ["pct"] = 60,
        },
        ["NECK"] = {
            ["itemID"] = 251173,
            ["pct"] = 20,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271490,
            ["pct"] = 60,
        },
        ["CHEST"] = {
            ["itemID"] = 271495,
            ["pct"] = 60,
        },
        ["WAIST"] = {
            ["itemID"] = 263268,
            ["pct"] = 40,
        },
        ["LEGS"] = {
            ["itemID"] = 249987,
            ["pct"] = 60,
        },
        ["FEET"] = {
            ["itemID"] = 159388,
            ["pct"] = 20,
        },
        ["WRIST"] = {
            ["itemID"] = 244584,
            ["pct"] = 80,
        },
        ["HANDS"] = {
            ["itemID"] = 193752,
            ["pct"] = 40,
        },
        ["BACK"] = {
            ["itemID"] = 159288,
            ["pct"] = 20,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 158370,
            ["pct"] = 20,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 159136,
            ["pct"] = 20,
        },
        ["TABARD"] = {
            ["itemID"] = 31405,
            ["pct"] = 20,
        },
        ["SHIRT"] = {
            ["itemID"] = 268274,
            ["pct"] = 20,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 60,
        },
        ["FINGER_2"] = {
            ["itemID"] = 252258,
            ["pct"] = 40,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249806,
            ["pct"] = 40,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250228,
            ["pct"] = 40,
        },
    },
    ["HUNTER_SURVIVAL_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 212020,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 178707,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 212018,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 212023,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 221075,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 212019,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 219335,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 219342,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 212021,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 133363,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222448,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 221141,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 215135,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 133282,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 212454,
            ["pct"] = 50,
        },
    },
    ["PRIEST_DISCIPLINE_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 239047,
            ["pct"] = 25,
        },
        ["NECK"] = {
            ["itemID"] = 251173,
            ["pct"] = 25,
        },
        ["SHOULDER"] = {
            ["itemID"] = 239031,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 271558,
            ["pct"] = 75,
        },
        ["WAIST"] = {
            ["itemID"] = 239649,
            ["pct"] = 25,
        },
        ["LEGS"] = {
            ["itemID"] = 271554,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 159243,
            ["pct"] = 25,
        },
        ["WRIST"] = {
            ["itemID"] = 251127,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 271556,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 159288,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245770,
            ["pct"] = 50,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 245769,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 273792,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 49812,
            ["pct"] = 25,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 25,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249808,
            ["pct"] = 25,
        },
    },
    ["PRIEST_DISCIPLINE_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 229334,
            ["pct"] = 75,
        },
        ["NECK"] = {
            ["itemID"] = 215134,
            ["pct"] = 25,
        },
        ["SHOULDER"] = {
            ["itemID"] = 229332,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 229337,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 178822,
            ["pct"] = 25,
        },
        ["LEGS"] = {
            ["itemID"] = 229333,
            ["pct"] = 75,
        },
        ["FEET"] = {
            ["itemID"] = 222814,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 222815,
            ["pct"] = 75,
        },
        ["HANDS"] = {
            ["itemID"] = 229335,
            ["pct"] = 75,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222568,
            ["pct"] = 50,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 222566,
            ["pct"] = 50,
        },
        ["TABARD"] = {
            ["itemID"] = 179282,
            ["pct"] = 25,
        },
        ["FINGER_1"] = {
            ["itemID"] = 228411,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 231265,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 190958,
            ["pct"] = 25,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 219308,
            ["pct"] = 25,
        },
    },
    ["MONK_BREWMASTER_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271519,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 268291,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250013,
            ["pct"] = 30,
        },
        ["SHIRT"] = {
            ["itemID"] = 167196,
            ["pct"] = 10,
        },
        ["CHEST"] = {
            ["itemID"] = 251226,
            ["pct"] = 40,
        },
        ["WAIST"] = {
            ["itemID"] = 251189,
            ["pct"] = 30,
        },
        ["LEGS"] = {
            ["itemID"] = 271518,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 159327,
            ["pct"] = 20,
        },
        ["WRIST"] = {
            ["itemID"] = 244576,
            ["pct"] = 30,
        },
        ["HANDS"] = {
            ["itemID"] = 271520,
            ["pct"] = 40,
        },
        ["BACK"] = {
            ["itemID"] = 251132,
            ["pct"] = 40,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245771,
            ["pct"] = 30,
        },
        ["TABARD"] = {
            ["itemID"] = 5976,
            ["pct"] = 10,
        },
        ["FINGER_1"] = {
            ["itemID"] = 251136,
            ["pct"] = 40,
        },
        ["FINGER_2"] = {
            ["itemID"] = 158366,
            ["pct"] = 30,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 30,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250259,
            ["pct"] = 30,
        },
    },
    ["MONK_BREWMASTER_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 229298,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 185842,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 237671,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 237676,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 219502,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 237672,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 221120,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 185817,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 237674,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 185779,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 178824,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 211052,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 219308,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 219309,
            ["pct"] = 100,
        },
    },
    ["WARRIOR_FURY_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271456,
            ["pct"] = 75,
        },
        ["NECK"] = {
            ["itemID"] = 251142,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 249950,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 271459,
            ["pct"] = 75,
        },
        ["WAIST"] = {
            ["itemID"] = 159418,
            ["pct"] = 25,
        },
        ["LEGS"] = {
            ["itemID"] = 271455,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 268260,
            ["pct"] = 75,
        },
        ["WRIST"] = {
            ["itemID"] = 237834,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 271457,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 159288,
            ["pct"] = 25,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237846,
            ["pct"] = 50,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 268213,
            ["pct"] = 50,
        },
        ["TABARD"] = {
            ["itemID"] = 38311,
            ["pct"] = 25,
        },
        ["FINGER_1"] = {
            ["itemID"] = 252258,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 268290,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 273796,
            ["pct"] = 50,
        },
    },
    ["WARRIOR_FURY_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 211984,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 178707,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 211982,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 211987,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 222473,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 211983,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 212443,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 221167,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 222479,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 222835,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222470,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 222470,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 215130,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 219301,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 222680,
            ["pct"] = 100,
        },
    },
    ["DEATHKNIGHT_UNHOLY_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 249970,
            ["pct"] = 60,
        },
        ["NECK"] = {
            ["itemID"] = 251234,
            ["pct"] = 40,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271472,
            ["pct"] = 60,
        },
        ["CHEST"] = {
            ["itemID"] = 271477,
            ["pct"] = 80,
        },
        ["WAIST"] = {
            ["itemID"] = 159418,
            ["pct"] = 20,
        },
        ["LEGS"] = {
            ["itemID"] = 271473,
            ["pct"] = 80,
        },
        ["FEET"] = {
            ["itemID"] = 159412,
            ["pct"] = 20,
        },
        ["WRIST"] = {
            ["itemID"] = 237834,
            ["pct"] = 60,
        },
        ["HANDS"] = {
            ["itemID"] = 249971,
            ["pct"] = 40,
        },
        ["BACK"] = {
            ["itemID"] = 251132,
            ["pct"] = 60,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237846,
            ["pct"] = 60,
        },
        ["FINGER_1"] = {
            ["itemID"] = 158366,
            ["pct"] = 20,
        },
        ["FINGER_2"] = {
            ["itemID"] = 193708,
            ["pct"] = 20,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249344,
            ["pct"] = 80,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249343,
            ["pct"] = 60,
        },
    },
    ["DEATHKNIGHT_UNHOLY_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 249970,
            ["pct"] = 71,
        },
        ["NECK"] = {
            ["itemID"] = 268291,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 249968,
            ["pct"] = 43,
        },
        ["CHEST"] = {
            ["itemID"] = 249973,
            ["pct"] = 86,
        },
        ["WAIST"] = {
            ["itemID"] = 268289,
            ["pct"] = 71,
        },
        ["LEGS"] = {
            ["itemID"] = 249969,
            ["pct"] = 57,
        },
        ["FEET"] = {
            ["itemID"] = 249381,
            ["pct"] = 71,
        },
        ["WRIST"] = {
            ["itemID"] = 237834,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 249971,
            ["pct"] = 71,
        },
        ["BACK"] = {
            ["itemID"] = 239656,
            ["pct"] = 43,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237846,
            ["pct"] = 43,
        },
        ["SHIRT"] = {
            ["itemID"] = 268274,
            ["pct"] = 14,
        },
        ["FINGER_1"] = {
            ["itemID"] = 249919,
            ["pct"] = 71,
        },
        ["FINGER_2"] = {
            ["itemID"] = 249369,
            ["pct"] = 43,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249344,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249343,
            ["pct"] = 86,
        },
    },
    ["ROGUE_ASSASSINATION_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250006,
            ["pct"] = 40,
        },
        ["NECK"] = {
            ["itemID"] = 251173,
            ["pct"] = 20,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271508,
            ["pct"] = 80,
        },
        ["CHEST"] = {
            ["itemID"] = 271513,
            ["pct"] = 80,
        },
        ["WAIST"] = {
            ["itemID"] = 268286,
            ["pct"] = 40,
        },
        ["LEGS"] = {
            ["itemID"] = 271509,
            ["pct"] = 80,
        },
        ["FEET"] = {
            ["itemID"] = 159304,
            ["pct"] = 60,
        },
        ["WRIST"] = {
            ["itemID"] = 244576,
            ["pct"] = 60,
        },
        ["HANDS"] = {
            ["itemID"] = 271511,
            ["pct"] = 40,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 60,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237837,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 159136,
            ["pct"] = 20,
        },
        ["FINGER_1"] = {
            ["itemID"] = 252258,
            ["pct"] = 40,
        },
        ["FINGER_2"] = {
            ["itemID"] = 273792,
            ["pct"] = 40,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 159617,
            ["pct"] = 20,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 193701,
            ["pct"] = 20,
        },
    },
    ["ROGUE_ASSASSINATION_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 229289,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 215136,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 229287,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 235417,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 245964,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 229288,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 219327,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 219334,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 229290,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 231266,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 168962,
            ["pct"] = 100,
        },
        ["TABARD"] = {
            ["itemID"] = 233288,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 215135,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 231265,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 230027,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 230198,
            ["pct"] = 100,
        },
    },
    ["SHAMAN_RESTORATION_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271483,
            ["pct"] = 63,
        },
        ["NECK"] = {
            ["itemID"] = 273781,
            ["pct"] = 38,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271481,
            ["pct"] = 75,
        },
        ["CHEST"] = {
            ["itemID"] = 271486,
            ["pct"] = 63,
        },
        ["WAIST"] = {
            ["itemID"] = 251155,
            ["pct"] = 38,
        },
        ["LEGS"] = {
            ["itemID"] = 271482,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 251125,
            ["pct"] = 63,
        },
        ["WRIST"] = {
            ["itemID"] = 159380,
            ["pct"] = 38,
        },
        ["HANDS"] = {
            ["itemID"] = 271484,
            ["pct"] = 38,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 38,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 273778,
            ["pct"] = 25,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 237831,
            ["pct"] = 50,
        },
        ["SHIRT"] = {
            ["itemID"] = 10055,
            ["pct"] = 13,
        },
        ["FINGER_1"] = {
            ["itemID"] = 273792,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 158366,
            ["pct"] = 38,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 264507,
            ["pct"] = 38,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250255,
            ["pct"] = 25,
        },
    },
    ["SHAMAN_RESTORATION_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 237637,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 228842,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 237635,
            ["pct"] = 100,
        },
        ["SHIRT"] = {
            ["itemID"] = 2576,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 237640,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 245965,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 237636,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 228862,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 229258,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 229263,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222445,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 222432,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 221200,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 228843,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 230186,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 242400,
            ["pct"] = 100,
        },
    },
    ["MAGE_FROST_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250060,
            ["pct"] = 67,
        },
        ["NECK"] = {
            ["itemID"] = 249337,
            ["pct"] = 33,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250058,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 250063,
            ["pct"] = 83,
        },
        ["WAIST"] = {
            ["itemID"] = 239649,
            ["pct"] = 33,
        },
        ["LEGS"] = {
            ["itemID"] = 250059,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 251137,
            ["pct"] = 33,
        },
        ["WRIST"] = {
            ["itemID"] = 239648,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 250061,
            ["pct"] = 83,
        },
        ["BACK"] = {
            ["itemID"] = 250055,
            ["pct"] = 33,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245770,
            ["pct"] = 83,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 249922,
            ["pct"] = 17,
        },
        ["FINGER_1"] = {
            ["itemID"] = 193708,
            ["pct"] = 33,
        },
        ["FINGER_2"] = {
            ["itemID"] = 268290,
            ["pct"] = 33,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 83,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249346,
            ["pct"] = 50,
        },
    },
    ["MAGE_FROST_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 212092,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 225577,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 178696,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 223299,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 221087,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 219178,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 219181,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 219175,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 212093,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 221088,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222568,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 211061,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 221136,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 159622,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 219314,
            ["pct"] = 100,
        },
    },
    ["MAGE_ARCANE_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271564,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 251142,
            ["pct"] = 25,
        },
        ["SHOULDER"] = {
            ["itemID"] = 239045,
            ["pct"] = 38,
        },
        ["SHIRT"] = {
            ["itemID"] = 18231,
            ["pct"] = 13,
        },
        ["CHEST"] = {
            ["itemID"] = 271567,
            ["pct"] = 63,
        },
        ["WAIST"] = {
            ["itemID"] = 251185,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 271563,
            ["pct"] = 63,
        },
        ["FEET"] = {
            ["itemID"] = 159243,
            ["pct"] = 63,
        },
        ["WRIST"] = {
            ["itemID"] = 251127,
            ["pct"] = 38,
        },
        ["HANDS"] = {
            ["itemID"] = 271565,
            ["pct"] = 63,
        },
        ["BACK"] = {
            ["itemID"] = 159288,
            ["pct"] = 25,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245770,
            ["pct"] = 38,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 245769,
            ["pct"] = 25,
        },
        ["FINGER_1"] = {
            ["itemID"] = 159459,
            ["pct"] = 63,
        },
        ["FINGER_2"] = {
            ["itemID"] = 272148,
            ["pct"] = 25,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 250215,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250224,
            ["pct"] = 25,
        },
    },
    ["MAGE_ARCANE_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 237548,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 211063,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 237716,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 237965,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 242664,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 237717,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 221149,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 237864,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 243502,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 211059,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 237570,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 243498,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 219314,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 238386,
            ["pct"] = 100,
        },
    },
    ["PALADIN_HOLY_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271465,
            ["pct"] = 45,
        },
        ["NECK"] = {
            ["itemID"] = 273781,
            ["pct"] = 55,
        },
        ["SHOULDER"] = {
            ["itemID"] = 249959,
            ["pct"] = 45,
        },
        ["CHEST"] = {
            ["itemID"] = 271468,
            ["pct"] = 36,
        },
        ["WAIST"] = {
            ["itemID"] = 159442,
            ["pct"] = 27,
        },
        ["LEGS"] = {
            ["itemID"] = 271464,
            ["pct"] = 36,
        },
        ["FEET"] = {
            ["itemID"] = 159412,
            ["pct"] = 27,
        },
        ["WRIST"] = {
            ["itemID"] = 159409,
            ["pct"] = 27,
        },
        ["HANDS"] = {
            ["itemID"] = 271466,
            ["pct"] = 45,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 36,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237843,
            ["pct"] = 91,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 251196,
            ["pct"] = 45,
        },
        ["TABARD"] = {
            ["itemID"] = 5976,
            ["pct"] = 9,
        },
        ["FINGER_1"] = {
            ["itemID"] = 252258,
            ["pct"] = 82,
        },
        ["FINGER_2"] = {
            ["itemID"] = 158366,
            ["pct"] = 36,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 250214,
            ["pct"] = 45,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 270162,
            ["pct"] = 27,
        },
    },
    ["PALADIN_HOLY_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 211993,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 215144,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 211034,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 211996,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 133289,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 211992,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 212443,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 222435,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 211994,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 225574,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222444,
            ["pct"] = 50,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 178750,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 133287,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 159461,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 178708,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 212452,
            ["pct"] = 50,
        },
    },
    ["PALADIN_RETRIBUTION_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271465,
            ["pct"] = 71,
        },
        ["NECK"] = {
            ["itemID"] = 251234,
            ["pct"] = 57,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271463,
            ["pct"] = 43,
        },
        ["CHEST"] = {
            ["itemID"] = 271468,
            ["pct"] = 71,
        },
        ["WAIST"] = {
            ["itemID"] = 268289,
            ["pct"] = 57,
        },
        ["LEGS"] = {
            ["itemID"] = 271464,
            ["pct"] = 57,
        },
        ["FEET"] = {
            ["itemID"] = 159412,
            ["pct"] = 29,
        },
        ["WRIST"] = {
            ["itemID"] = 159409,
            ["pct"] = 43,
        },
        ["HANDS"] = {
            ["itemID"] = 271466,
            ["pct"] = 57,
        },
        ["BACK"] = {
            ["itemID"] = 251132,
            ["pct"] = 57,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237846,
            ["pct"] = 86,
        },
        ["TABARD"] = {
            ["itemID"] = 264164,
            ["pct"] = 14,
        },
        ["FINGER_1"] = {
            ["itemID"] = 158366,
            ["pct"] = 71,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251136,
            ["pct"] = 29,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 193701,
            ["pct"] = 86,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249343,
            ["pct"] = 43,
        },
    },
    ["PALADIN_RETRIBUTION_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 237619,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 215136,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 237617,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 237622,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 221133,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 237618,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 222429,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 221118,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 237620,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 159638,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 215135,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 221136,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 219314,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 232541,
            ["pct"] = 100,
        },
    },
    ["WARRIOR_ARMS_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271456,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 251173,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271454,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 251151,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 159418,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 159435,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 193728,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 237834,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 271457,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 239656,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 251134,
            ["pct"] = 50,
        },
        ["SHIRT"] = {
            ["itemID"] = 167082,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 252258,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 256972,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 248583,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249342,
            ["pct"] = 50,
        },
    },
    ["WARRIOR_ARMS_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 249952,
            ["pct"] = 83,
        },
        ["NECK"] = {
            ["itemID"] = 268291,
            ["pct"] = 33,
        },
        ["SHOULDER"] = {
            ["itemID"] = 249950,
            ["pct"] = 83,
        },
        ["CHEST"] = {
            ["itemID"] = 249955,
            ["pct"] = 67,
        },
        ["WAIST"] = {
            ["itemID"] = 249949,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 249951,
            ["pct"] = 83,
        },
        ["FEET"] = {
            ["itemID"] = 249381,
            ["pct"] = 33,
        },
        ["WRIST"] = {
            ["itemID"] = 237834,
            ["pct"] = 67,
        },
        ["HANDS"] = {
            ["itemID"] = 237836,
            ["pct"] = 17,
        },
        ["BACK"] = {
            ["itemID"] = 239656,
            ["pct"] = 33,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237846,
            ["pct"] = 33,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 67,
        },
        ["FINGER_2"] = {
            ["itemID"] = 273792,
            ["pct"] = 33,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249342,
            ["pct"] = 67,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250229,
            ["pct"] = 33,
        },
    },
    ["WARRIOR_PROTECTION_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271456,
            ["pct"] = 60,
        },
        ["NECK"] = {
            ["itemID"] = 251234,
            ["pct"] = 60,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271454,
            ["pct"] = 80,
        },
        ["CHEST"] = {
            ["itemID"] = 271459,
            ["pct"] = 40,
        },
        ["WAIST"] = {
            ["itemID"] = 159442,
            ["pct"] = 40,
        },
        ["LEGS"] = {
            ["itemID"] = 249951,
            ["pct"] = 20,
        },
        ["FEET"] = {
            ["itemID"] = 273777,
            ["pct"] = 60,
        },
        ["WRIST"] = {
            ["itemID"] = 237834,
            ["pct"] = 40,
        },
        ["HANDS"] = {
            ["itemID"] = 271457,
            ["pct"] = 60,
        },
        ["BACK"] = {
            ["itemID"] = 159288,
            ["pct"] = 60,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237839,
            ["pct"] = 40,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 237831,
            ["pct"] = 40,
        },
        ["FINGER_1"] = {
            ["itemID"] = 252258,
            ["pct"] = 60,
        },
        ["FINGER_2"] = {
            ["itemID"] = 159459,
            ["pct"] = 40,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 250228,
            ["pct"] = 60,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249342,
            ["pct"] = 20,
        },
    },
    ["WARRIOR_PROTECTION_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 178777,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 221181,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 211982,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 211987,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 222431,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 211983,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 221178,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 156263,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 211985,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 222817,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 117356,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 222432,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 143901,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 228411,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 219300,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 219314,
            ["pct"] = 100,
        },
    },
    ["HUNTER_BEASTMASTERY_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 249988,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 251142,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 249986,
            ["pct"] = 25,
        },
        ["SHIRT"] = {
            ["itemID"] = 268274,
            ["pct"] = 25,
        },
        ["CHEST"] = {
            ["itemID"] = 249991,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 244611,
            ["pct"] = 25,
        },
        ["LEGS"] = {
            ["itemID"] = 249987,
            ["pct"] = 75,
        },
        ["FEET"] = {
            ["itemID"] = 159388,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 244584,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 249989,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 251132,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 265337,
            ["pct"] = 50,
        },
        ["TABARD"] = {
            ["itemID"] = 233288,
            ["pct"] = 25,
        },
        ["FINGER_1"] = {
            ["itemID"] = 158366,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 162544,
            ["pct"] = 25,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 193701,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249343,
            ["pct"] = 25,
        },
    },
    ["HUNTER_BEASTMASTERY_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 229271,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 228841,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 229269,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 237649,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 245965,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 229270,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 228862,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 219342,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 229272,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 228893,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 228840,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 228843,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 230027,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 230198,
            ["pct"] = 100,
        },
    },
    ["HUNTER_MARKSMANSHIP_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271492,
            ["pct"] = 75,
        },
        ["NECK"] = {
            ["itemID"] = 251234,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271490,
            ["pct"] = 63,
        },
        ["CHEST"] = {
            ["itemID"] = 271495,
            ["pct"] = 75,
        },
        ["WAIST"] = {
            ["itemID"] = 251155,
            ["pct"] = 38,
        },
        ["LEGS"] = {
            ["itemID"] = 271491,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 159388,
            ["pct"] = 38,
        },
        ["WRIST"] = {
            ["itemID"] = 244584,
            ["pct"] = 75,
        },
        ["HANDS"] = {
            ["itemID"] = 271493,
            ["pct"] = 63,
        },
        ["BACK"] = {
            ["itemID"] = 251132,
            ["pct"] = 38,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 265337,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 251136,
            ["pct"] = 63,
        },
        ["FINGER_2"] = {
            ["itemID"] = 158366,
            ["pct"] = 38,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 193701,
            ["pct"] = 38,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 273796,
            ["pct"] = 38,
        },
    },
    ["HUNTER_MARKSMANSHIP_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 237646,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 185842,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 237644,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 237649,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 245965,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 237645,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 178830,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 237523,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 219341,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 185783,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 178824,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 215130,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 190958,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 242396,
            ["pct"] = 100,
        },
    },
    ["PRIEST_SHADOW_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271555,
            ["pct"] = 80,
        },
        ["NECK"] = {
            ["itemID"] = 251173,
            ["pct"] = 40,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271553,
            ["pct"] = 60,
        },
        ["CHEST"] = {
            ["itemID"] = 271558,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 239649,
            ["pct"] = 40,
        },
        ["LEGS"] = {
            ["itemID"] = 271554,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 251137,
            ["pct"] = 80,
        },
        ["WRIST"] = {
            ["itemID"] = 251127,
            ["pct"] = 60,
        },
        ["HANDS"] = {
            ["itemID"] = 271556,
            ["pct"] = 80,
        },
        ["BACK"] = {
            ["itemID"] = 251132,
            ["pct"] = 40,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 273778,
            ["pct"] = 40,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 245769,
            ["pct"] = 20,
        },
        ["SHIRT"] = {
            ["itemID"] = 167185,
            ["pct"] = 20,
        },
        ["FINGER_1"] = {
            ["itemID"] = 251136,
            ["pct"] = 80,
        },
        ["FINGER_2"] = {
            ["itemID"] = 158366,
            ["pct"] = 40,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 60,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249346,
            ["pct"] = 40,
        },
    },
    ["PRIEST_SHADOW_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 229334,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 251880,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 246276,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 229337,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 228882,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 229333,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 224667,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 221104,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 229335,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 222817,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 228896,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 185812,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 228411,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 235820,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 219305,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 219308,
            ["pct"] = 100,
        },
    },
    ["ROGUE_SUBTLETY_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250006,
            ["pct"] = 38,
        },
        ["NECK"] = {
            ["itemID"] = 268291,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250004,
            ["pct"] = 50,
        },
        ["SHIRT"] = {
            ["itemID"] = 3428,
            ["pct"] = 13,
        },
        ["CHEST"] = {
            ["itemID"] = 271513,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 251189,
            ["pct"] = 38,
        },
        ["LEGS"] = {
            ["itemID"] = 271509,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 244569,
            ["pct"] = 38,
        },
        ["WRIST"] = {
            ["itemID"] = 244576,
            ["pct"] = 63,
        },
        ["HANDS"] = {
            ["itemID"] = 271511,
            ["pct"] = 63,
        },
        ["BACK"] = {
            ["itemID"] = 159288,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237837,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 251180,
            ["pct"] = 25,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251194,
            ["pct"] = 38,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250259,
            ["pct"] = 25,
        },
    },
    ["ROGUE_SUBTLETY_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 240775,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 246196,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 240760,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 240777,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 240778,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 240779,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 240764,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 240781,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 240782,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 240255,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 242564,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 242565,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 246199,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 246200,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 245999,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 246207,
            ["pct"] = 100,
        },
    },
    ["DRUID_FERAL_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271528,
            ["pct"] = 57,
        },
        ["NECK"] = {
            ["itemID"] = 251234,
            ["pct"] = 29,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271526,
            ["pct"] = 57,
        },
        ["CHEST"] = {
            ["itemID"] = 250027,
            ["pct"] = 43,
        },
        ["WAIST"] = {
            ["itemID"] = 159317,
            ["pct"] = 29,
        },
        ["LEGS"] = {
            ["itemID"] = 271527,
            ["pct"] = 57,
        },
        ["FEET"] = {
            ["itemID"] = 251153,
            ["pct"] = 29,
        },
        ["WRIST"] = {
            ["itemID"] = 244576,
            ["pct"] = 86,
        },
        ["HANDS"] = {
            ["itemID"] = 250025,
            ["pct"] = 29,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 43,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 273783,
            ["pct"] = 29,
        },
        ["SHIRT"] = {
            ["itemID"] = 268274,
            ["pct"] = 29,
        },
        ["TABARD"] = {
            ["itemID"] = 5976,
            ["pct"] = 14,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 57,
        },
        ["FINGER_2"] = {
            ["itemID"] = 273792,
            ["pct"] = 29,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 193701,
            ["pct"] = 71,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250228,
            ["pct"] = 29,
        },
    },
    ["DRUID_FERAL_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 212056,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 221077,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 212054,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 212059,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 225723,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 127249,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 221169,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 219334,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 151403,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 211005,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222448,
            ["pct"] = 50,
        },
        ["TABARD"] = {
            ["itemID"] = 233288,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 178736,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 221189,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 219314,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 225638,
            ["pct"] = 50,
        },
    },
    ["DRUID_GUARDIAN_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 273791,
            ["pct"] = 40,
        },
        ["NECK"] = {
            ["itemID"] = 273781,
            ["pct"] = 40,
        },
        ["SHOULDER"] = {
            ["itemID"] = 273774,
            ["pct"] = 30,
        },
        ["CHEST"] = {
            ["itemID"] = 239048,
            ["pct"] = 30,
        },
        ["WAIST"] = {
            ["itemID"] = 159301,
            ["pct"] = 30,
        },
        ["LEGS"] = {
            ["itemID"] = 250023,
            ["pct"] = 30,
        },
        ["FEET"] = {
            ["itemID"] = 159304,
            ["pct"] = 20,
        },
        ["WRIST"] = {
            ["itemID"] = 244576,
            ["pct"] = 40,
        },
        ["HANDS"] = {
            ["itemID"] = 159337,
            ["pct"] = 40,
        },
        ["BACK"] = {
            ["itemID"] = 159288,
            ["pct"] = 30,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245771,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 30,
        },
        ["FINGER_2"] = {
            ["itemID"] = 151311,
            ["pct"] = 20,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 250225,
            ["pct"] = 30,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250228,
            ["pct"] = 20,
        },
    },
    ["DRUID_GUARDIAN_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 134240,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 237474,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 134374,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 137336,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 232727,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 237448,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 237446,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 237451,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 134239,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 136770,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237776,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 134530,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 237471,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 234717,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 237495,
            ["pct"] = 100,
        },
    },
    ["DRUID_RESTORATION_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271528,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 251142,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250022,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 250027,
            ["pct"] = 25,
        },
        ["WAIST"] = {
            ["itemID"] = 159317,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 250023,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 159327,
            ["pct"] = 25,
        },
        ["WRIST"] = {
            ["itemID"] = 244576,
            ["pct"] = 38,
        },
        ["HANDS"] = {
            ["itemID"] = 250025,
            ["pct"] = 38,
        },
        ["BACK"] = {
            ["itemID"] = 159288,
            ["pct"] = 25,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 251156,
            ["pct"] = 38,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 245769,
            ["pct"] = 25,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 88,
        },
        ["FINGER_2"] = {
            ["itemID"] = 252258,
            ["pct"] = 38,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249809,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249343,
            ["pct"] = 13,
        },
    },
    ["DRUID_RESTORATION_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 219476,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 178827,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 156441,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 242482,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 245964,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 178819,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 246274,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 219471,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 237683,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 178829,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 215130,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 242491,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 219310,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 242494,
            ["pct"] = 100,
        },
    },
    ["WARLOCK_DESTRUCTION_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250042,
            ["pct"] = 56,
        },
        ["NECK"] = {
            ["itemID"] = 251142,
            ["pct"] = 33,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250040,
            ["pct"] = 22,
        },
        ["CHEST"] = {
            ["itemID"] = 271549,
            ["pct"] = 44,
        },
        ["WAIST"] = {
            ["itemID"] = 250039,
            ["pct"] = 33,
        },
        ["LEGS"] = {
            ["itemID"] = 250041,
            ["pct"] = 44,
        },
        ["FEET"] = {
            ["itemID"] = 268282,
            ["pct"] = 33,
        },
        ["WRIST"] = {
            ["itemID"] = 239648,
            ["pct"] = 56,
        },
        ["HANDS"] = {
            ["itemID"] = 250043,
            ["pct"] = 44,
        },
        ["BACK"] = {
            ["itemID"] = 239656,
            ["pct"] = 33,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245770,
            ["pct"] = 44,
        },
        ["SHIRT"] = {
            ["itemID"] = 98092,
            ["pct"] = 11,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 245769,
            ["pct"] = 22,
        },
        ["FINGER_1"] = {
            ["itemID"] = 249336,
            ["pct"] = 22,
        },
        ["FINGER_2"] = {
            ["itemID"] = 268290,
            ["pct"] = 22,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 44,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 273794,
            ["pct"] = 33,
        },
    },
    ["WARLOCK_DESTRUCTION_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 219179,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 225575,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 212072,
            ["pct"] = 50,
        },
        ["SHIRT"] = {
            ["itemID"] = 4330,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 212077,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 168958,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 212073,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 222814,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 211014,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 212075,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 219183,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222568,
            ["pct"] = 50,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 221056,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 215130,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 219187,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 137367,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 225649,
            ["pct"] = 50,
        },
    },
    ["PRIEST_HOLY_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 251199,
            ["pct"] = 20,
        },
        ["NECK"] = {
            ["itemID"] = 251234,
            ["pct"] = 60,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271553,
            ["pct"] = 80,
        },
        ["CHEST"] = {
            ["itemID"] = 271558,
            ["pct"] = 60,
        },
        ["WAIST"] = {
            ["itemID"] = 239664,
            ["pct"] = 40,
        },
        ["LEGS"] = {
            ["itemID"] = 271554,
            ["pct"] = 60,
        },
        ["FEET"] = {
            ["itemID"] = 251137,
            ["pct"] = 40,
        },
        ["WRIST"] = {
            ["itemID"] = 251154,
            ["pct"] = 60,
        },
        ["HANDS"] = {
            ["itemID"] = 273773,
            ["pct"] = 40,
        },
        ["BACK"] = {
            ["itemID"] = 251190,
            ["pct"] = 40,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245770,
            ["pct"] = 80,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 245769,
            ["pct"] = 20,
        },
        ["FINGER_1"] = {
            ["itemID"] = 251148,
            ["pct"] = 60,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251194,
            ["pct"] = 40,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 20,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250214,
            ["pct"] = 20,
        },
    },
    ["PRIEST_HOLY_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 237709,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 228841,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 229332,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 237712,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 242664,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 229333,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 229336,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 237558,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 237549,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 228901,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 237742,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 215135,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 231265,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 219312,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 242392,
            ["pct"] = 100,
        },
    },
    ["MAGE_FIRE_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250060,
            ["pct"] = 63,
        },
        ["NECK"] = {
            ["itemID"] = 251142,
            ["pct"] = 38,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250058,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 250063,
            ["pct"] = 38,
        },
        ["WAIST"] = {
            ["itemID"] = 239649,
            ["pct"] = 38,
        },
        ["LEGS"] = {
            ["itemID"] = 250059,
            ["pct"] = 75,
        },
        ["FEET"] = {
            ["itemID"] = 159259,
            ["pct"] = 25,
        },
        ["WRIST"] = {
            ["itemID"] = 151305,
            ["pct"] = 25,
        },
        ["HANDS"] = {
            ["itemID"] = 250061,
            ["pct"] = 75,
        },
        ["BACK"] = {
            ["itemID"] = 159288,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245770,
            ["pct"] = 63,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 193766,
            ["pct"] = 13,
        },
        ["TABARD"] = {
            ["itemID"] = 45585,
            ["pct"] = 13,
        },
        ["FINGER_1"] = {
            ["itemID"] = 252258,
            ["pct"] = 38,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251093,
            ["pct"] = 25,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 250144,
            ["pct"] = 38,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 273796,
            ["pct"] = 38,
        },
    },
    ["MAGE_FIRE_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 237718,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 228841,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 229341,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 229346,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 242664,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 229342,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 229345,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 222815,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 229344,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 228896,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 222566,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 178871,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 215135,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 230192,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 230198,
            ["pct"] = 100,
        },
    },
    ["DEATHKNIGHT_BLOOD_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271474,
            ["pct"] = 75,
        },
        ["NECK"] = {
            ["itemID"] = 251173,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271472,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 271477,
            ["pct"] = 38,
        },
        ["WAIST"] = {
            ["itemID"] = 159418,
            ["pct"] = 63,
        },
        ["LEGS"] = {
            ["itemID"] = 271473,
            ["pct"] = 63,
        },
        ["FEET"] = {
            ["itemID"] = 273777,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 159425,
            ["pct"] = 38,
        },
        ["HANDS"] = {
            ["itemID"] = 271475,
            ["pct"] = 63,
        },
        ["BACK"] = {
            ["itemID"] = 251190,
            ["pct"] = 38,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 193755,
            ["pct"] = 38,
        },
        ["TABARD"] = {
            ["itemID"] = 233288,
            ["pct"] = 13,
        },
        ["FINGER_1"] = {
            ["itemID"] = 252258,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 273792,
            ["pct"] = 38,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 250228,
            ["pct"] = 25,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250229,
            ["pct"] = 25,
        },
    },
    ["DEATHKNIGHT_BLOOD_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 212002,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 225577,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 212000,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 212005,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 225589,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 212001,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 222429,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 212437,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 212003,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 225574,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222443,
            ["pct"] = 100,
        },
        ["TABARD"] = {
            ["itemID"] = 69210,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 162541,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 225578,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 212450,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 219314,
            ["pct"] = 100,
        },
    },
    ["DEATHKNIGHT_FROST_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 251126,
            ["pct"] = 40,
        },
        ["NECK"] = {
            ["itemID"] = 251234,
            ["pct"] = 80,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271472,
            ["pct"] = 60,
        },
        ["CHEST"] = {
            ["itemID"] = 271477,
            ["pct"] = 80,
        },
        ["WAIST"] = {
            ["itemID"] = 159418,
            ["pct"] = 20,
        },
        ["LEGS"] = {
            ["itemID"] = 271473,
            ["pct"] = 80,
        },
        ["FEET"] = {
            ["itemID"] = 193728,
            ["pct"] = 60,
        },
        ["WRIST"] = {
            ["itemID"] = 237834,
            ["pct"] = 60,
        },
        ["HANDS"] = {
            ["itemID"] = 271475,
            ["pct"] = 40,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 40,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237839,
            ["pct"] = 40,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 158373,
            ["pct"] = 40,
        },
        ["SHIRT"] = {
            ["itemID"] = 268274,
            ["pct"] = 20,
        },
        ["TABARD"] = {
            ["itemID"] = 233288,
            ["pct"] = 20,
        },
        ["FINGER_1"] = {
            ["itemID"] = 251136,
            ["pct"] = 60,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251513,
            ["pct"] = 40,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 250259,
            ["pct"] = 40,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 273797,
            ["pct"] = 40,
        },
    },
    ["DEATHKNIGHT_FROST_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 229253,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 215136,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 229251,
            ["pct"] = 100,
        },
        ["SHIRT"] = {
            ["itemID"] = 151116,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 229256,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 245966,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 229252,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 222429,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 222435,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 229254,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 232526,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 215135,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 231265,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 230027,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 232485,
            ["pct"] = 100,
        },
    },
    ["ROGUE_OUTLAW_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271510,
            ["pct"] = 43,
        },
        ["NECK"] = {
            ["itemID"] = 273781,
            ["pct"] = 57,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250004,
            ["pct"] = 43,
        },
        ["CHEST"] = {
            ["itemID"] = 250009,
            ["pct"] = 57,
        },
        ["WAIST"] = {
            ["itemID"] = 251235,
            ["pct"] = 29,
        },
        ["LEGS"] = {
            ["itemID"] = 250005,
            ["pct"] = 57,
        },
        ["FEET"] = {
            ["itemID"] = 244569,
            ["pct"] = 43,
        },
        ["WRIST"] = {
            ["itemID"] = 251183,
            ["pct"] = 43,
        },
        ["HANDS"] = {
            ["itemID"] = 250007,
            ["pct"] = 71,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 43,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237839,
            ["pct"] = 71,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 275070,
            ["pct"] = 57,
        },
        ["FINGER_1"] = {
            ["itemID"] = 49812,
            ["pct"] = 43,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251194,
            ["pct"] = 29,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 86,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250225,
            ["pct"] = 29,
        },
    },
    ["ROGUE_OUTLAW_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 240775,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 246193,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 240776,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 240777,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 240746,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 247090,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 240780,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 240781,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 240339,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 240258,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 242588,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 242604,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 246197,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 246198,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 246000,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 246206,
            ["pct"] = 100,
        },
    },
    ["SHAMAN_ELEMENTAL_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271483,
            ["pct"] = 78,
        },
        ["NECK"] = {
            ["itemID"] = 251142,
            ["pct"] = 33,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271481,
            ["pct"] = 67,
        },
        ["CHEST"] = {
            ["itemID"] = 271486,
            ["pct"] = 67,
        },
        ["WAIST"] = {
            ["itemID"] = 251228,
            ["pct"] = 44,
        },
        ["LEGS"] = {
            ["itemID"] = 159375,
            ["pct"] = 33,
        },
        ["FEET"] = {
            ["itemID"] = 244577,
            ["pct"] = 33,
        },
        ["WRIST"] = {
            ["itemID"] = 244584,
            ["pct"] = 33,
        },
        ["HANDS"] = {
            ["itemID"] = 271484,
            ["pct"] = 56,
        },
        ["BACK"] = {
            ["itemID"] = 251190,
            ["pct"] = 22,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 273778,
            ["pct"] = 44,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 251150,
            ["pct"] = 22,
        },
        ["SHIRT"] = {
            ["itemID"] = 3427,
            ["pct"] = 11,
        },
        ["TABARD"] = {
            ["itemID"] = 118372,
            ["pct"] = 11,
        },
        ["FINGER_1"] = {
            ["itemID"] = 158366,
            ["pct"] = 56,
        },
        ["FINGER_2"] = {
            ["itemID"] = 252258,
            ["pct"] = 33,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 273796,
            ["pct"] = 56,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250214,
            ["pct"] = 44,
        },
    },
    ["SHAMAN_ELEMENTAL_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 237637,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 178827,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 237635,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 237640,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 245965,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 237636,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 237982,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 219342,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 237638,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222445,
            ["pct"] = 50,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 222432,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 215135,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 221141,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 242497,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 242402,
            ["pct"] = 50,
        },
    },
    ["WARLOCK_AFFLICTION_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250042,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 273781,
            ["pct"] = 38,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271544,
            ["pct"] = 38,
        },
        ["CHEST"] = {
            ["itemID"] = 250045,
            ["pct"] = 63,
        },
        ["WAIST"] = {
            ["itemID"] = 193691,
            ["pct"] = 25,
        },
        ["LEGS"] = {
            ["itemID"] = 250041,
            ["pct"] = 38,
        },
        ["FEET"] = {
            ["itemID"] = 250044,
            ["pct"] = 25,
        },
        ["WRIST"] = {
            ["itemID"] = 239648,
            ["pct"] = 63,
        },
        ["HANDS"] = {
            ["itemID"] = 250043,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 25,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245770,
            ["pct"] = 25,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 245769,
            ["pct"] = 13,
        },
        ["TABARD"] = {
            ["itemID"] = 233288,
            ["pct"] = 13,
        },
        ["FINGER_1"] = {
            ["itemID"] = 273792,
            ["pct"] = 38,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251217,
            ["pct"] = 25,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 38,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 273794,
            ["pct"] = 38,
        },
    },
    ["WARLOCK_AFFLICTION_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 229325,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 215136,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 229323,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 229328,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 242664,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 229324,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 222814,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 222815,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 222822,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 222817,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222568,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 221099,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 231265,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 230027,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 230192,
            ["pct"] = 100,
        },
    },
    ["WARLOCK_DEMONOLOGY_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271546,
            ["pct"] = 86,
        },
        ["NECK"] = {
            ["itemID"] = 251173,
            ["pct"] = 43,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271544,
            ["pct"] = 43,
        },
        ["CHEST"] = {
            ["itemID"] = 271549,
            ["pct"] = 71,
        },
        ["WAIST"] = {
            ["itemID"] = 251185,
            ["pct"] = 43,
        },
        ["LEGS"] = {
            ["itemID"] = 271545,
            ["pct"] = 86,
        },
        ["FEET"] = {
            ["itemID"] = 251219,
            ["pct"] = 43,
        },
        ["WRIST"] = {
            ["itemID"] = 239648,
            ["pct"] = 57,
        },
        ["HANDS"] = {
            ["itemID"] = 271547,
            ["pct"] = 86,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 43,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245770,
            ["pct"] = 57,
        },
        ["SHIRT"] = {
            ["itemID"] = 268274,
            ["pct"] = 57,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 245769,
            ["pct"] = 29,
        },
        ["TABARD"] = {
            ["itemID"] = 178120,
            ["pct"] = 14,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 57,
        },
        ["FINGER_2"] = {
            ["itemID"] = 252258,
            ["pct"] = 43,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 250215,
            ["pct"] = 43,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250144,
            ["pct"] = 29,
        },
    },
    ["WARLOCK_DEMONOLOGY_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 212074,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 224594,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 221115,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 221095,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 224589,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 224598,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 219181,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 224591,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 211010,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 221088,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 219206,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 221189,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 224592,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 219321,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 222671,
            ["pct"] = 100,
        },
    },
    ["MONK_WINDWALKER_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271519,
            ["pct"] = 86,
        },
        ["NECK"] = {
            ["itemID"] = 251142,
            ["pct"] = 29,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271517,
            ["pct"] = 86,
        },
        ["CHEST"] = {
            ["itemID"] = 271522,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 159317,
            ["pct"] = 29,
        },
        ["LEGS"] = {
            ["itemID"] = 271518,
            ["pct"] = 71,
        },
        ["FEET"] = {
            ["itemID"] = 244569,
            ["pct"] = 29,
        },
        ["WRIST"] = {
            ["itemID"] = 244576,
            ["pct"] = 57,
        },
        ["HANDS"] = {
            ["itemID"] = 271520,
            ["pct"] = 86,
        },
        ["BACK"] = {
            ["itemID"] = 251132,
            ["pct"] = 43,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 273783,
            ["pct"] = 43,
        },
        ["TABARD"] = {
            ["itemID"] = 69209,
            ["pct"] = 14,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 193767,
            ["pct"] = 14,
        },
        ["FINGER_1"] = {
            ["itemID"] = 158366,
            ["pct"] = 43,
        },
        ["FINGER_2"] = {
            ["itemID"] = 252258,
            ["pct"] = 43,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 43,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250215,
            ["pct"] = 43,
        },
    },
    ["MONK_WINDWALKER_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 235224,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 237894,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 237887,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 232728,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 232727,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 229297,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 221120,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 234499,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 159305,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 178829,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 178824,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 242491,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 230353,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 230354,
            ["pct"] = 100,
        },
    },
    ["DRUID_BALANCE_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 250024,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 251142,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271526,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 271531,
            ["pct"] = 75,
        },
        ["WAIST"] = {
            ["itemID"] = 268286,
            ["pct"] = 75,
        },
        ["LEGS"] = {
            ["itemID"] = 271527,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 159304,
            ["pct"] = 75,
        },
        ["WRIST"] = {
            ["itemID"] = 244576,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 193758,
            ["pct"] = 25,
        },
        ["BACK"] = {
            ["itemID"] = 251132,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245770,
            ["pct"] = 25,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 245769,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 252258,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 158366,
            ["pct"] = 25,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 273796,
            ["pct"] = 50,
        },
    },
    ["DRUID_BALANCE_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 229307,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 215136,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 229305,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 229310,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 219331,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 168968,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 219327,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 221053,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 229308,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 221054,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222568,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 228411,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 178871,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 219308,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 219305,
            ["pct"] = 50,
        },
    },
    ["DEMONHUNTER_HAVOC_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271537,
            ["pct"] = 71,
        },
        ["NECK"] = {
            ["itemID"] = 251234,
            ["pct"] = 29,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250031,
            ["pct"] = 43,
        },
        ["CHEST"] = {
            ["itemID"] = 271540,
            ["pct"] = 57,
        },
        ["WAIST"] = {
            ["itemID"] = 159301,
            ["pct"] = 29,
        },
        ["LEGS"] = {
            ["itemID"] = 271536,
            ["pct"] = 86,
        },
        ["FEET"] = {
            ["itemID"] = 159327,
            ["pct"] = 71,
        },
        ["WRIST"] = {
            ["itemID"] = 244576,
            ["pct"] = 57,
        },
        ["HANDS"] = {
            ["itemID"] = 271538,
            ["pct"] = 57,
        },
        ["BACK"] = {
            ["itemID"] = 251132,
            ["pct"] = 57,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237840,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 251186,
            ["pct"] = 43,
        },
        ["FINGER_1"] = {
            ["itemID"] = 251136,
            ["pct"] = 57,
        },
        ["FINGER_2"] = {
            ["itemID"] = 158366,
            ["pct"] = 29,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 193701,
            ["pct"] = 43,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249343,
            ["pct"] = 43,
        },
    },
    ["DEMONHUNTER_HAVOC_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 154737,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 154747,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 154735,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 154739,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 154742,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 154736,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 154741,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 154740,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 154738,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 154748,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 160513,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 160513,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 154745,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 154746,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 154743,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 154744,
            ["pct"] = 100,
        },
    },
    ["DEMONHUNTER_VENGEANCE_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271537,
            ["pct"] = 40,
        },
        ["NECK"] = {
            ["itemID"] = 251173,
            ["pct"] = 30,
        },
        ["SHOULDER"] = {
            ["itemID"] = 251146,
            ["pct"] = 30,
        },
        ["SHIRT"] = {
            ["itemID"] = 6097,
            ["pct"] = 10,
        },
        ["CHEST"] = {
            ["itemID"] = 193764,
            ["pct"] = 20,
        },
        ["WAIST"] = {
            ["itemID"] = 159317,
            ["pct"] = 30,
        },
        ["LEGS"] = {
            ["itemID"] = 251130,
            ["pct"] = 30,
        },
        ["FEET"] = {
            ["itemID"] = 251153,
            ["pct"] = 40,
        },
        ["WRIST"] = {
            ["itemID"] = 251135,
            ["pct"] = 60,
        },
        ["HANDS"] = {
            ["itemID"] = 250034,
            ["pct"] = 40,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 30,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237840,
            ["pct"] = 100,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 251143,
            ["pct"] = 30,
        },
        ["TABARD"] = {
            ["itemID"] = 5976,
            ["pct"] = 10,
        },
        ["FINGER_1"] = {
            ["itemID"] = 159459,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 273792,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 40,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 250228,
            ["pct"] = 30,
        },
    },
    ["DEMONHUNTER_VENGEANCE_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 229316,
            ["pct"] = 50,
        },
        ["NECK"] = {
            ["itemID"] = 224594,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 211038,
            ["pct"] = 50,
        },
        ["CHEST"] = {
            ["itemID"] = 235439,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 245964,
            ["pct"] = 50,
        },
        ["LEGS"] = {
            ["itemID"] = 211018,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 221120,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 224605,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 229317,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 211006,
            ["pct"] = 50,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222441,
            ["pct"] = 50,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 222441,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 221198,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 224661,
            ["pct"] = 50,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 219308,
            ["pct"] = 50,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 225653,
            ["pct"] = 50,
        },
    },
    ["EVOKER_DEVASTATION_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271501,
            ["pct"] = 55,
        },
        ["NECK"] = {
            ["itemID"] = 251234,
            ["pct"] = 55,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271499,
            ["pct"] = 55,
        },
        ["CHEST"] = {
            ["itemID"] = 271504,
            ["pct"] = 36,
        },
        ["WAIST"] = {
            ["itemID"] = 49810,
            ["pct"] = 18,
        },
        ["LEGS"] = {
            ["itemID"] = 271500,
            ["pct"] = 45,
        },
        ["FEET"] = {
            ["itemID"] = 249999,
            ["pct"] = 27,
        },
        ["WRIST"] = {
            ["itemID"] = 244584,
            ["pct"] = 55,
        },
        ["HANDS"] = {
            ["itemID"] = 271502,
            ["pct"] = 36,
        },
        ["BACK"] = {
            ["itemID"] = 251132,
            ["pct"] = 36,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 273778,
            ["pct"] = 36,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 245769,
            ["pct"] = 64,
        },
        ["SHIRT"] = {
            ["itemID"] = 268274,
            ["pct"] = 18,
        },
        ["FINGER_1"] = {
            ["itemID"] = 251136,
            ["pct"] = 45,
        },
        ["FINGER_2"] = {
            ["itemID"] = 268290,
            ["pct"] = 27,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 273796,
            ["pct"] = 36,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249346,
            ["pct"] = 27,
        },
    },
    ["EVOKER_DEVASTATION_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 212029,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 212448,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 212027,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 212032,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 178700,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 212028,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 212431,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 219342,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 212030,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 221154,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222568,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 221141,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 225576,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 133304,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 220305,
            ["pct"] = 100,
        },
    },
    ["EVOKER_PRESERVATION_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271501,
            ["pct"] = 57,
        },
        ["NECK"] = {
            ["itemID"] = 251142,
            ["pct"] = 29,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271499,
            ["pct"] = 71,
        },
        ["CHEST"] = {
            ["itemID"] = 271504,
            ["pct"] = 43,
        },
        ["WAIST"] = {
            ["itemID"] = 159369,
            ["pct"] = 29,
        },
        ["LEGS"] = {
            ["itemID"] = 271500,
            ["pct"] = 86,
        },
        ["FEET"] = {
            ["itemID"] = 159388,
            ["pct"] = 29,
        },
        ["WRIST"] = {
            ["itemID"] = 251200,
            ["pct"] = 43,
        },
        ["HANDS"] = {
            ["itemID"] = 271502,
            ["pct"] = 43,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 43,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245770,
            ["pct"] = 29,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 245769,
            ["pct"] = 57,
        },
        ["FINGER_1"] = {
            ["itemID"] = 252258,
            ["pct"] = 43,
        },
        ["FINGER_2"] = {
            ["itemID"] = 273792,
            ["pct"] = 43,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249343,
            ["pct"] = 29,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 264507,
            ["pct"] = 29,
        },
    },
    ["EVOKER_PRESERVATION_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 237655,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 178827,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 237653,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 219336,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 185808,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 237654,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 243308,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 219342,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 237656,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 235499,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237730,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 178824,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 215135,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 242392,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 242400,
            ["pct"] = 100,
        },
    },
    ["EVOKER_AUGMENTATION_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271501,
            ["pct"] = 38,
        },
        ["NECK"] = {
            ["itemID"] = 268291,
            ["pct"] = 38,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271499,
            ["pct"] = 63,
        },
        ["CHEST"] = {
            ["itemID"] = 271504,
            ["pct"] = 38,
        },
        ["WAIST"] = {
            ["itemID"] = 49810,
            ["pct"] = 25,
        },
        ["LEGS"] = {
            ["itemID"] = 249996,
            ["pct"] = 50,
        },
        ["FEET"] = {
            ["itemID"] = 249999,
            ["pct"] = 25,
        },
        ["WRIST"] = {
            ["itemID"] = 244584,
            ["pct"] = 63,
        },
        ["HANDS"] = {
            ["itemID"] = 271502,
            ["pct"] = 50,
        },
        ["BACK"] = {
            ["itemID"] = 239656,
            ["pct"] = 25,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 245770,
            ["pct"] = 38,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 245769,
            ["pct"] = 38,
        },
        ["TABARD"] = {
            ["itemID"] = 69209,
            ["pct"] = 13,
        },
        ["SHIRT"] = {
            ["itemID"] = 52019,
            ["pct"] = 13,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 63,
        },
        ["FINGER_2"] = {
            ["itemID"] = 268249,
            ["pct"] = 25,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249346,
            ["pct"] = 38,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249810,
            ["pct"] = 25,
        },
    },
    ["EVOKER_AUGMENTATION_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 133285,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 178707,
            ["pct"] = 100,
        },
        ["SHOULDER"] = {
            ["itemID"] = 212027,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 229283,
            ["pct"] = 100,
        },
        ["WAIST"] = {
            ["itemID"] = 221101,
            ["pct"] = 100,
        },
        ["LEGS"] = {
            ["itemID"] = 229279,
            ["pct"] = 100,
        },
        ["FEET"] = {
            ["itemID"] = 221106,
            ["pct"] = 100,
        },
        ["WRIST"] = {
            ["itemID"] = 221059,
            ["pct"] = 100,
        },
        ["HANDS"] = {
            ["itemID"] = 212030,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 221054,
            ["pct"] = 100,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 222568,
            ["pct"] = 100,
        },
        ["FINGER_1"] = {
            ["itemID"] = 178869,
            ["pct"] = 100,
        },
        ["FINGER_2"] = {
            ["itemID"] = 178871,
            ["pct"] = 100,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 219296,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 230192,
            ["pct"] = 100,
        },
    },
    ["DEMONHUNTER_DEVOURER_MYTHICPLUS"] = {
        ["HEAD"] = {
            ["itemID"] = 271537,
            ["pct"] = 83,
        },
        ["NECK"] = {
            ["itemID"] = 251142,
            ["pct"] = 33,
        },
        ["SHOULDER"] = {
            ["itemID"] = 271535,
            ["pct"] = 83,
        },
        ["CHEST"] = {
            ["itemID"] = 271540,
            ["pct"] = 50,
        },
        ["WAIST"] = {
            ["itemID"] = 159301,
            ["pct"] = 33,
        },
        ["LEGS"] = {
            ["itemID"] = 250032,
            ["pct"] = 33,
        },
        ["FEET"] = {
            ["itemID"] = 244569,
            ["pct"] = 33,
        },
        ["WRIST"] = {
            ["itemID"] = 244576,
            ["pct"] = 33,
        },
        ["HANDS"] = {
            ["itemID"] = 271538,
            ["pct"] = 67,
        },
        ["BACK"] = {
            ["itemID"] = 193763,
            ["pct"] = 33,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 237840,
            ["pct"] = 83,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 273780,
            ["pct"] = 33,
        },
        ["FINGER_1"] = {
            ["itemID"] = 273792,
            ["pct"] = 50,
        },
        ["FINGER_2"] = {
            ["itemID"] = 251136,
            ["pct"] = 33,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249346,
            ["pct"] = 67,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249343,
            ["pct"] = 33,
        },
    },
    ["DEMONHUNTER_DEVOURER_RAID"] = {
        ["HEAD"] = {
            ["itemID"] = 250033,
            ["pct"] = 100,
        },
        ["NECK"] = {
            ["itemID"] = 249368,
            ["pct"] = 50,
        },
        ["SHOULDER"] = {
            ["itemID"] = 250031,
            ["pct"] = 100,
        },
        ["CHEST"] = {
            ["itemID"] = 250036,
            ["pct"] = 83,
        },
        ["WAIST"] = {
            ["itemID"] = 244573,
            ["pct"] = 33,
        },
        ["LEGS"] = {
            ["itemID"] = 49817,
            ["pct"] = 33,
        },
        ["FEET"] = {
            ["itemID"] = 250035,
            ["pct"] = 50,
        },
        ["WRIST"] = {
            ["itemID"] = 244576,
            ["pct"] = 50,
        },
        ["HANDS"] = {
            ["itemID"] = 250034,
            ["pct"] = 100,
        },
        ["BACK"] = {
            ["itemID"] = 249370,
            ["pct"] = 33,
        },
        ["MAIN_HAND"] = {
            ["itemID"] = 249280,
            ["pct"] = 50,
        },
        ["OFF_HAND"] = {
            ["itemID"] = 237840,
            ["pct"] = 50,
        },
        ["FINGER_1"] = {
            ["itemID"] = 268290,
            ["pct"] = 83,
        },
        ["FINGER_2"] = {
            ["itemID"] = 249369,
            ["pct"] = 33,
        },
        ["TRINKET_1"] = {
            ["itemID"] = 249346,
            ["pct"] = 100,
        },
        ["TRINKET_2"] = {
            ["itemID"] = 249343,
            ["pct"] = 83,
        },
    },
}
